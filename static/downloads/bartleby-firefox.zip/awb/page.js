/* Author Workbench, on the tab. Runs where the session cookie is same-origin,
   the CSRF token is in the DOM and DOMParser is available — which is all it
   takes: creating a lab, attaching it to a course and writing its instructions
   are each one request to the page's own routes, made as the signed-in author.
   No token, no OAuth application, nothing to set up.

   Content scripts can't be ES modules, so this file stands alone and takes the
   page context from the caller rather than working it out twice. */
(() => {
  if (window.__myScribeAwbReady) return;
  window.__myScribeAwbReady = true;

  const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;

  const ORIGIN = location.origin;

  function csrf() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta || !meta.content) {
      throw new Error('no CSRF token on this page — are you signed in to Author Workbench?');
    }
    return meta.content;
  }

  // Brace-balanced slice, so a comma or a quote inside a tool description
  // can't fool us into cutting the payload short.
  function sliceObject(text, from) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = from; i < text.length; i++) {
      const ch = text[i];
      if (inString) {
        escaped = !escaped && ch === '\\';
        if (!escaped && ch === '"') inString = false;
      } else if (ch === '"') inString = true;
      else if (ch === '{') depth++;
      else if (ch === '}' && --depth === 0) return text.slice(from, i + 1);
    }
    throw new Error('unbalanced object in the lab tool picker payload');
  }

  /* ------------------------------ creating ------------------------------ */

  // All four things that carry the context — container type, container id,
  // owning organization, lab tool — are already rendered into /labs/new, so
  // scrape the real form instead of hand-assembling params. Passing the
  // container makes the server pick the course's organization as owner rather
  // than the user's.
  async function fetchNewLabForm(container) {
    const query = container
      ? `?labable_type=${encodeURIComponent(container.labableType)}&labable_id=${encodeURIComponent(container.labableId)}`
      : '';
    const res = await fetch(`${ORIGIN}/labs/new${query}`, { credentials: 'include' });
    if (res.status === 401 || res.status === 403) {
      throw new Error('Author Workbench would not open the new-lab form — check you can create labs here.');
    }
    if (!res.ok) throw new Error(`GET /labs/new -> ${res.status}`);

    const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
    const form = doc.querySelector('form[action^="/labs"]');
    if (!form) throw new Error('no lab form on /labs/new — the page may have changed');

    const holder = doc.querySelector('[x-data^="labToolPicker"]');
    if (!holder) throw new Error('no lab tool picker on /labs/new — the page may have changed');
    const xdata = holder.getAttribute('x-data');
    const tools = JSON.parse(sliceObject(xdata, xdata.indexOf('{')));

    return { form, tools };
  }

  // Tool ids are per-environment database rows, so they are never hardcoded.
  // versions is newest-first and each entry carries a disabled flag saying
  // whether this user may use it.
  function instructionalToolId(tools) {
    const picker = tools['instructional-lab'];
    const version = picker && picker.versions && picker.versions.find((v) => !v.disabled);
    if (!version) throw new Error('no instructional-lab version is available to your account');
    return version.id;
  }

  async function createLab({ name, description, container }) {
    const { form, tools } = await fetchNewLabForm(container);

    // Start from the real form so the hidden ownership fields come along
    // untouched.
    const body = new URLSearchParams();
    for (const [key, value] of new FormData(form)) {
      if (typeof value === 'string') body.set(key, value);
    }
    body.set('authenticity_token', csrf());
    body.set('lab[name]', name);
    body.set('lab[description]', description || '');
    body.set('lab[lab_tool_id]', instructionalToolId(tools));

    // The one place to deviate from the form: with the association present the
    // response redirects to the course page and we never learn the new lab's
    // id. Attach it in a second request instead.
    body.delete('lab[lab_association][labable_type]');
    body.delete('lab[lab_association][labable_id]');

    const res = await fetch(`${ORIGIN}/labs`, {
      method: 'POST',
      credentials: 'include',
      redirect: 'follow',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'text/html' },
      body,
    });

    const labId = new URL(res.url).pathname.match(/^\/labs\/(\d+)/)?.[1];
    if (!labId) throw new Error(`creating the lab failed (${res.status}) — landed on ${res.url}`);

    let attached = false;
    if (container) attached = await attachLab(labId, container);
    return { labId, attached };
  }

  // Comma-separated ids, so several labs can be attached at once.
  async function attachLab(labId, container) {
    const res = await fetch(`${ORIGIN}/${container.segment}/${container.labableId}/add_lab`, {
      method: 'POST',
      credentials: 'include',
      redirect: 'follow',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'text/html' },
      body: new URLSearchParams({ authenticity_token: csrf(), ids: labId }),
    });
    if (res.status === 401 || res.status === 403) {
      throw new Error('the lab was created, but you do not have permission to add labs here');
    }
    if (!res.ok) throw new Error(`add_lab -> ${res.status}`);
    return true;
  }

  /* ------------------------------- writing ------------------------------ */

  // One request writes the instructions. The screenshots ride inside the
  // markdown as data: URIs; Author Workbench moves them into the version's file
  // library and rewrites the references before it stores the draft, so the
  // draft that lands already points at public URLs. Each call is a new draft
  // and publish=true additionally makes it live — re-running is safe and
  // leaves history.
  //
  // This round-trips a file service once per image and can be slow. No
  // timeout and no retry: a retried slow request is a duplicate draft, and
  // drafts are the author's visible history.
  async function writeDraft({ labId, markdown, changelog, publish }) {
    // A file part, not a string field: the multipart encoder normalises a
    // string field's newlines to CRLF, and a stray \r at the end of a
    // ::directive line is enough to stop it being one. Bytes in a file part
    // are sent as they are.
    const form = new FormData();
    form.set('file', new Blob([markdown], { type: 'text/markdown' }), 'lab.md');
    form.set('draft[changelog]', changelog || 'Synced from Bartleby');
    form.set('publish', publish ? 'true' : 'false');

    const res = await fetch(`${ORIGIN}/labs/${encodeURIComponent(labId)}/versions/latest/drafts`, {
      method: 'POST',
      credentials: 'include',
      headers: { Accept: 'application/json', 'X-CSRF-Token': csrf() },
      body: form,
    });

    const text = await res.text();
    let body = null;
    try {
      body = JSON.parse(text);
    } catch {
      // not JSON — a sign-in page, a proxy error page; handled below
    }

    if (res.status === 401) throw new Error('Author Workbench wants you to sign in — reload the tab and sign in first.');
    if (res.status === 403) throw new Error("You don't have edit access to this lab.");
    if (res.status === 404) throw new Error('No such lab — check the lab id.');
    if (res.status === 413) {
      throw new Error('The capture is too large to send in one request — narrow or remove some screenshots and try again.');
    }
    if (!res.ok) throw new Error((body && body.error) || `writing the draft failed (${res.status})`);
    if (!body) throw new Error('Author Workbench answered with a page instead of JSON — are you signed in?');
    return body; // { id, lab_id, lab_version_id, published, lab_url }
  }

  // A lab id on its own tells the author nothing; the name confirms which lab
  // is about to get a new draft. Read off the lab's own page.
  async function labInfo(labId) {
    const res = await fetch(`${ORIGIN}/labs/${encodeURIComponent(labId)}`, {
      credentials: 'include',
      headers: { Accept: 'text/html' },
    });
    if (res.status === 404) throw new Error('No such lab — check the lab id.');
    if (!res.ok) throw new Error(`Could not read lab ${labId} (${res.status}).`);
    const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
    const h1 = doc.querySelector('h1');
    const name = (h1 && h1.textContent.trim()) || (doc.title || '').split('|')[0].trim();
    return { labId, name: name || null };
  }

  webext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('awb:')) return;

    const reply = (work) => {
      Promise.resolve()
        .then(work)
        .then(
          (value) => sendResponse({ ok: true, value }),
          (err) => sendResponse({ ok: false, error: (err && err.message) || String(err) }),
        );
      return true;
    };

    switch (msg.type) {
      case 'awb:ping':
        sendResponse({ ok: true, value: { origin: ORIGIN, signedIn: !!document.querySelector('meta[name="csrf-token"]') } });
        return false;
      case 'awb:createLab':
        return reply(() => createLab(msg));
      case 'awb:attachLab':
        return reply(() => attachLab(msg.labId, msg.container));
      case 'awb:writeDraft':
        return reply(() => writeDraft(msg));
      case 'awb:lab':
        return reply(() => labInfo(msg.labId));
    }
  });
})();
