/* Author Workbench, drawn on the page.

   This card is the one place a capture is sent from. The popup and the editor
   have a button that opens an Author Workbench tab and opens this card on it,
   so there is a single sheet to learn: where the lab lands, what to call it,
   whether to publish, and one big link to the lab when it is done.

   It hides itself while recording. A screenshot photographs the tab, so a panel
   painted into the page would land in the pictures it is meant to describe —
   the same reason the live panel is a side panel and not an overlay.

   Content scripts can't be ES modules, so the storage key this reads is
   written out rather than imported; lib/store.js owns it. */
(() => {
  if (window.__myScribeAwbLauncher) return;
  window.__myScribeAwbLauncher = true;

  const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;

  const K_PREFS = 'ms:prefs';
  const HOST_ID = 'myscribe-awb-launcher';

  let brief = null;      // context and counts — asked for on open
  let open = false;
  let pushing = false;
  let done = null;       // { url, labId, publish, created } once a push lands
  let lookupSeq = 0;
  let lookupTimer = null;

  // A content script outlives the extension that injected it. Reloading the
  // extension — which is what installing a new build does — leaves this one
  // running in an already-open tab whose extension runtime is dead, and every call
  // through it throws "Extension context invalidated". sendMessage throws that
  // one *synchronously*, so a .catch() on the promise it never returns cannot
  // see it: it escapes whatever async function called ask() and lands in the
  // console as an unhandled rejection. Which is what an author sees on the AWB
  // tab they had open while installing a new build — once per tab focus,
  // because coming back to the tab is what asks again.
  //
  // There is no reconnecting. This script cannot reach the worker again for as
  // long as the page lives, so the first sign of it retires the launcher: off
  // the page, and nothing left that would ask a second time. The new build is
  // already injected into every tab loaded from here on, and reloading this one
  // brings it straight back.
  let dead = false;

  const alive = () => {
    try {
      return !!(webext.runtime && webext.runtime.id);
    } catch {
      return false;
    }
  };

  // Idempotent: ask() routes every later call here too, and taking the
  // launcher off the page is a thing to do once rather than per attempt.
  function retire() {
    if (!dead) {
      dead = true;
      remove();
    }
    return { ok: false, error: 'Extension context invalidated' };
  }

  const ask = async (msg) => {
    if (dead || !alive()) return retire();
    try {
      return await webext.runtime.sendMessage(msg);
    } catch (err) {
      // Only an invalidated context is fatal. A sleeping worker rejects too,
      // and that one is worth reporting and retrying.
      if (!alive()) return retire();
      return { ok: false, error: (err && err.message) || String(err) };
    }
  };

  /* ------------------------------ the shell ------------------------------ */

  const host = document.createElement('div');
  host.id = HOST_ID;
  host.style.cssText = 'all: initial; position: fixed; z-index: 2147483000;';
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
<style>
  :host { all: initial; }
  * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
  [hidden] { display: none !important; }
  .wrap {
    position: fixed;
    right: 18px;
    bottom: 18px;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 10px;
    color: #14161C;
  }
  .pill {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 14px 9px 11px;
    border: 0;
    border-radius: 999px;
    background: #14161C;
    color: #fff;
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    box-shadow: 0 10px 28px rgba(20, 22, 28, 0.32);
    cursor: pointer;
  }
  .pill:hover { background: #22252F; }
  .pill svg { width: 16px; height: 16px; }
  .pill .ring, .pill .ticks { fill: none; stroke: #FF0A6C; stroke-width: 8; stroke-linecap: round; }
  .pill .ticks { opacity: 0.6; }
  .pill .core { fill: #FF0A6C; }
  .card {
    width: 328px;
    max-height: min(78vh, 620px);
    overflow-y: auto;
    padding: 16px;
    border-radius: 14px;
    background: #fff;
    box-shadow: 0 22px 60px rgba(20, 22, 28, 0.34);
  }
  .head { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; }
  .head h2 {
    margin: 0;
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
    font-size: 10.5px;
    font-weight: 700;
    letter-spacing: 0.16em;
    text-transform: uppercase;
  }
  .x {
    border: 0;
    background: none;
    color: #5A6472;
    font-size: 15px;
    line-height: 1;
    cursor: pointer;
  }
  .x:hover { color: #14161C; }
  .where { margin: 8px 0 0; font-size: 12px; line-height: 1.5; color: #5A6472; }
  .chip {
    display: inline-block;
    padding: 1px 6px;
    border-radius: 999px;
    background: #EDEFF3;
    color: #14161C;
    font-family: ui-monospace, Menlo, monospace;
    font-size: 9.5px;
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }
  label.field { display: block; margin-top: 11px; }
  label.field span {
    display: block;
    margin-bottom: 4px;
    font-family: ui-monospace, Menlo, monospace;
    font-size: 9px;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: #5A6472;
  }
  input[type="text"] {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #C9CEDA;
    border-radius: 8px;
    background: #fff;
    color: #14161C;
    font-size: 13px;
  }
  input[type="text"]:focus { outline: 2px solid #FF0A6C; outline-offset: 1px; }
  .lookup { margin: 5px 0 0; font-size: 11px; line-height: 1.4; color: #5A6472; min-height: 1.4em; }
  .lookup.good { color: #0F9D58; }
  .lookup.bad { color: #C2410C; }
  .check { display: flex; align-items: center; gap: 8px; margin-top: 12px; font-size: 12px; color: #5A6472; }
  .check input { margin: 0; accent-color: #FF0A6C; }
  .row { display: flex; gap: 8px; margin-top: 13px; }
  .btn {
    flex: 1;
    padding: 10px 12px;
    border: 1px solid #C9CEDA;
    border-radius: 9px;
    background: #fff;
    color: #14161C;
    font-family: ui-monospace, Menlo, monospace;
    font-size: 10.5px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
  }
  .btn:hover:not(:disabled) { border-color: #14161C; }
  .btn.solid { border-color: #FF0A6C; background: #FF0A6C; color: #fff; }
  .btn.solid:hover:not(:disabled) { filter: brightness(1.08); }
  .btn:disabled { opacity: 0.4; cursor: default; }
  .btn.big { display: block; width: 100%; padding: 13px 14px; font-size: 12px; }
  .log { list-style: none; margin: 12px 0 0; padding: 0; }
  .log li {
    padding: 2px 0;
    font-family: ui-monospace, Menlo, monospace;
    font-size: 10.5px;
    line-height: 1.5;
    color: #5A6472;
  }
  .log li.good { color: #0F9D58; }
  .log li.bad { color: #C2410C; }
  .done { margin-top: 14px; padding-top: 14px; border-top: 1px solid #EDEFF3; }
  .done-title { margin: 0 0 4px; font-size: 15px; font-weight: 600; line-height: 1.3; }
  .done-sub { margin: 0 0 12px; font-size: 12px; line-height: 1.5; color: #5A6472; }
  .again { display: block; margin: 10px auto 0; }
  .foot { display: flex; gap: 12px; margin-top: 14px; padding-top: 11px; border-top: 1px solid #EDEFF3; }
  .link {
    padding: 0;
    border: 0;
    background: none;
    color: #5A6472;
    font-size: 11px;
    text-decoration: none;
    cursor: pointer;
  }
  .link:hover { color: #FF0A6C; text-decoration: underline; }
  @media (prefers-reduced-motion: no-preference) {
    .card { animation: rise 140ms cubic-bezier(.2,.85,.25,1); }
    @keyframes rise { from { opacity: 0; transform: translateY(6px); } }
  }
</style>
<div class="wrap">
  <section class="card" id="card" hidden aria-label="Send this capture to Author Workbench">
    <div class="head">
      <h2>Send to Workbench</h2>
      <button class="x" id="close" type="button" aria-label="Close">&#10005;</button>
    </div>
    <div id="form">
      <p class="where" id="where"></p>
      <label class="field" id="nameField"><span>Lab name</span><input id="labName" type="text" autocomplete="off"></label>
      <label class="field" id="idField"><span>Lab id to update</span><input id="labId" type="text" autocomplete="off" inputmode="numeric"></label>
      <p class="lookup" id="lookup"></p>
      <label class="field"><span>Changelog</span><input id="changelog" type="text" autocomplete="off" placeholder="Synced from Bartleby"></label>
      <label class="check"><input type="checkbox" id="publish" checked><span>Publish it, not just a draft</span></label>
      <div class="row">
        <button class="btn solid" id="create" type="button">Create lab</button>
        <button class="btn" id="update" type="button">Update lab</button>
      </div>
    </div>
    <ol class="log" id="log"></ol>
    <div class="done" id="doneBox" hidden>
      <p class="done-title" id="doneTitle"></p>
      <p class="done-sub" id="doneSub"></p>
      <a class="btn solid big" id="openLab" href="#" target="_blank" rel="noreferrer">Open the lab &rarr;</a>
      <button class="link again" id="again" type="button">Send it again</button>
    </div>
    <div class="foot">
      <button class="link" id="hide" type="button">Hide on pages</button>
    </div>
  </section>
  <button class="pill" id="pill" type="button" aria-haspopup="dialog">
    <svg viewBox="0 0 100 100" aria-hidden="true">
      <path d="M50 6 V18 M50 82 V94 M6 50 H18 M82 50 H94" class="ticks"/>
      <circle cx="50" cy="50" r="30" class="ring"/>
      <circle cx="50" cy="50" r="11" class="core"/>
    </svg>
    <span id="pillText">Bartleby</span>
  </button>
</div>`;

  const $ = (id) => root.getElementById(id);

  /* ------------------------------- wiring -------------------------------- */

  $('pill').addEventListener('click', () => (open ? close() : show()));
  $('close').addEventListener('click', close);
  $('create').addEventListener('click', () => push('create'));
  $('update').addEventListener('click', () => push('update'));
  $('again').addEventListener('click', () => {
    done = null;
    $('log').replaceChildren();
    draw();
    lookupLab();
  });

  $('labId').addEventListener('input', () => {
    draw();
    clearTimeout(lookupTimer);
    lookupTimer = setTimeout(lookupLab, 300);
  });

  // Off for good rather than for this page view, and the popup offers it back.
  $('hide').addEventListener('click', async () => {
    // Extension storage goes the same way as the runtime, and the launcher is
    // coming off the page either way — so a dead context just skips the pref.
    try {
      const { [K_PREFS]: prefs } = await webext.storage.local.get(K_PREFS);
      await webext.storage.local.set({ [K_PREFS]: { ...(prefs || {}), pageLauncher: false } });
    } catch {}
    remove();
  });

  root.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && open) {
      e.stopPropagation();
      close();
    }
  });

  webext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string') return false;
    if (msg.type === 'awb:progress') {
      line(msg.text);
      return false;
    }
    // Recording is the one state that must take the launcher off the page.
    if (msg.type === 'ms:recording') {
      if (msg.recording) hide();
      else refresh();
      return false;
    }
    if (msg.type === 'ms:launcher') {
      if (msg.on) refresh();
      else remove();
      return false;
    }
    // The popup and the editor send people here: open the card, even if the
    // pill has been hidden on this page.
    if (msg.type === 'ms:openCard') {
      refresh({ force: true }).then(() => {
        show();
        sendResponse({ ok: true, value: { open } });
      });
      return true;
    }
    if (msg.type === 'ms:stepAdded' || msg.type === 'ms:cleared') refresh();
    return false;
  });

  // Steps are usually recorded on some other tab; coming back to this one is
  // the moment to find out how many there are now.
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refresh();
  });

  start();

  /* ------------------------------ behaviour ------------------------------ */

  async function start() {
    let prefs = null;
    try {
      ({ [K_PREFS]: prefs } = await webext.storage.local.get(K_PREFS));
    } catch {
      retire();
      return;
    }
    if (prefs && prefs.pageLauncher === false) return;
    await refresh();
  }

  // The cheap ask: is anything recorded, and are we mid-recording. An AWB page
  // load costs nothing more than one message. `force` mounts the card even with
  // nothing recorded, for a hand that asked for it from the popup.
  async function refresh({ force = false } = {}) {
    if (dead) return;
    const res = await ask({ type: 'ms:brief' });
    if (!res || !res.ok) return;
    const info = res.value;
    if (info.recording || (!force && !info.count && !info.sections)) {
      hide();
      return;
    }
    mount();
    $('pillText').textContent = info.count === 1 ? '1 step' : `${info.count} steps`;
    brief = { ...(brief || {}), count: info.count, sections: info.sections || 0, title: info.title, awb: info.awb };
    if (open) draw();
  }

  // `all: initial` on the host resets `display` too, which means the hidden
  // attribute would not hide it. The inline display declaration comes after,
  // so it is the one that wins.
  function mount() {
    if (!host.isConnected) (document.body || document.documentElement).append(host);
    host.style.display = 'block';
  }

  function hide() {
    host.style.display = 'none';
    open = false;
    $('card').hidden = true;
  }

  function remove() {
    host.remove();
  }

  async function show() {
    open = true;
    $('card').hidden = false;
    draw();
    const res = await ask({ type: 'awb:brief', url: location.href });
    if (res && res.ok) brief = { ...brief, ...res.value };
    draw();
    if (labId()) lookupLab();
  }

  function close() {
    open = false;
    $('card').hidden = true;
    $('pill').focus();
  }

  const context = () => (brief && brief.context) || null;
  const remembered = () => (brief && brief.awb) || null;
  const labId = () => $('labId').value.trim();

  function draw() {
    const ctx = context();
    const memory = remembered();
    const count = (brief && brief.count) || 0;
    const sections = (brief && brief.sections) || 0;
    const has = count + sections > 0;
    const label = count
      ? `${count} step${count === 1 ? '' : 's'}`
      : has
        ? `${sections} section${sections === 1 ? '' : 's'}`
        : 'Nothing recorded yet';

    if (!$('labName').value) $('labName').value = (brief && brief.title) || '';
    if (!$('labId').value) {
      $('labId').value = (ctx && ctx.labId)
        || (memory && (!ctx || memory.origin === ctx.origin) ? memory.labId : '')
        || '';
    }

    const where = $('where');
    if (!has) {
      where.textContent = 'Record a flow first — every click becomes a step of the lab.';
    } else if (ctx && ctx.container) {
      setChipSentence(
        where,
        `${label} become a new lab in `,
        `${ctx.container.labableType} ${ctx.container.labableId}`,
        ', or a new draft of a lab you name.',
      );
    } else if (ctx && ctx.labId) {
      setChipSentence(where, `${label} become a new draft of `, `Lab ${ctx.labId}`, '.');
    } else {
      where.textContent = `${label} become a lab. This page isn't a course, quicklab, article or activity, so a new lab is created on its own.`;
    }

    $('create').disabled = pushing || !has;
    $('update').disabled = pushing || !has || !labId();

    // The finished state replaces the form: one loud link to the lab, and a
    // way back for the next push.
    const finished = !!(done && done.url);
    $('form').hidden = finished;
    $('doneBox').hidden = !finished;
    if (finished) {
      $('doneTitle').textContent = `Lab ${done.labId} ${done.publish ? 'published' : 'saved as a draft'}`;
      $('doneSub').textContent = done.created
        ? `Created${done.attached ? ' and added to the course' : ''}, with ${label} inside.`
        : `A new draft with ${label} inside.`;
      $('openLab').href = done.url;
    }
  }

  // A lab id on its own tells the author nothing; the name confirms which lab
  // is about to get a new draft.
  async function lookupLab() {
    const id = labId();
    const seq = ++lookupSeq;
    const out = $('lookup');
    if (!id) {
      out.textContent = '';
      out.className = 'lookup';
      return;
    }
    if (!/^\d+$/.test(id)) {
      out.textContent = 'Lab ids are numbers — find it in the lab’s URL: /labs/1284.';
      out.className = 'lookup';
      return;
    }
    out.textContent = 'Looking it up…';
    out.className = 'lookup';
    const res = await ask({ type: 'awb:lab', labId: id });
    if (seq !== lookupSeq) return;
    if (res && res.ok) {
      const name = res.value && res.value.name;
      out.textContent = name ? `Updating “${name}”.` : `Lab ${id}.`;
      out.className = 'lookup good';
    } else {
      out.textContent = (res && res.error) || 'Could not look the lab up.';
      out.className = 'lookup bad';
    }
  }

  async function push(mode) {
    if (pushing) return;
    pushing = true;
    done = null;
    $('log').replaceChildren();
    draw();

    const ctx = context();
    const res = await ask({
      type: 'awb:push',
      mode,
      origin: location.origin,
      container: mode === 'create' && ctx ? ctx.container : null,
      name: $('labName').value.trim() || (brief && brief.title) || '',
      description: '',
      labId: mode === 'create' ? null : labId(),
      changelog: $('changelog').value.trim() || 'Synced from Bartleby',
      publish: $('publish').checked,
    });

    pushing = false;

    if (!res || !res.ok) {
      line((res && res.error) || 'the push failed', 'bad');
      line('nothing was published', 'bad');
      // A create can fail after the lab exists. Point the retry at that lab so
      // it doesn't leave a trail of empty ones behind.
      const again = await ask({ type: 'ms:brief' });
      if (again && again.ok && again.value.awb && again.value.awb.labId) {
        $('labId').value = again.value.awb.labId;
        line(`lab ${again.value.awb.labId} exists — retry as an update`);
        lookupLab();
      }
      draw();
      return;
    }

    const out = res.value;
    done = { url: out.url, labId: out.labId, publish: !!out.publish, created: !!out.created, attached: !!out.attached };
    $('labId').value = String(out.labId);
    line(
      `${out.created ? 'created and wrote' : 'wrote'} lab ${out.labId}` +
        `${out.publish ? ' and published it' : ' as a draft'}`,
      'good',
    );
    draw();
    $('openLab').focus();
  }

  function line(text, kind) {
    if (!text) return;
    const li = document.createElement('li');
    li.textContent = text;
    if (kind) li.className = kind;
    $('log').append(li);
    $('log').lastElementChild.scrollIntoView({ block: 'nearest' });
  }

  function setChipSentence(element, before, chipText, after) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = chipText;
    element.replaceChildren(document.createTextNode(before), chip, document.createTextNode(after));
  }

})();
