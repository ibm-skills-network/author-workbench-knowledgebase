/* Bartleby content script: while recording, watches what the user clicks and
   types and reports the point, the target's bounds and a readable title. Runs
   in every frame; child frames forward their coordinates up to the top frame
   so the numbers always match the visible-tab screenshot. */
(() => {
  // Manifest registration handles pages opened from now on; the background
  // also injects this file into tabs that were already open when recording
  // started, so guard against wiring up twice.
  if (window.__myScribeReady) return;
  window.__myScribeReady = true;

  const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;

  const isTop = window.top === window;
  const FORWARD = 'myscribe:hit';
  const NEAR_MS = 400;
  const NEAR_PX = 8;

  let recording = false;
  let last = { x: -1, y: -1, t: 0 };
  let typing = null; // the field currently being filled in, if any
  let keySeq = 0;

  // Every frame runs its own copy of this script, so plain counters would
  // collide across frames and fold two unrelated steps together.
  const keyNS = Math.random().toString(36).slice(2, 8);

  // Identifies an element across events within this page load, so the service
  // worker can tell that "clicked the search box" and "typed into the search
  // box" are the same target and fold them into one step.
  const keys = new WeakMap();
  const keyFor = (el) => {
    if (!el) return null;
    if (!keys.has(el)) keys.set(el, `${keyNS}-${++keySeq}`);
    return keys.get(el);
  };

  ask({ type: 'ms:getState' }, (res) => {
    if (res) recording = !!res.recording;
  });

  try {
    webext.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== 'ms:recording') return;
      recording = !!msg.recording;
      if (typing) {
        clearTimeout(typing.idle); // half-typed field from before: not a step
        clearTimeout(typing.trail);
        typing = null;
      }
    });
  } catch {}

  const eventName = window.PointerEvent ? 'pointerdown' : 'mousedown';
  document.addEventListener(eventName, onDown, true);
  document.addEventListener('input', onInput, true);
  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('change', onChange, true);
  document.addEventListener('focusout', () => flushTyping(false), true);
  window.addEventListener('pagehide', () => flushTyping(false));

  // Every frame listens, not just the top one: a hit from a grandchild frame
  // has to be translated at each level on its way up, or it never arrives.
  window.addEventListener('message', onFrameMessage);

  function onDown(e) {
    if (!recording || !e.isTrusted || e.button !== 0) return;

    // pointerdown lands before focusout, so an unflushed field would be
    // reported after the click that left it. Flush first to keep the order.
    if (typing && typing.el !== deepTarget(e)) {
      flushTyping(false);
    } else if (typing) {
      return; // moving the cursor inside the field being filled in isn't a step
    }

    const now = Date.now();
    if (now - last.t < NEAR_MS && Math.abs(e.clientX - last.x) < NEAR_PX && Math.abs(e.clientY - last.y) < NEAR_PX) {
      return; // second half of a double-click
    }
    last = { x: e.clientX, y: e.clientY, t: now };

    const el = resolveTarget(deepTarget(e));

    send({
      kind: 'click',
      x: e.clientX,
      y: e.clientY,
      rect: rectOf(el),
      title: titleFor(el),
      targetKey: keyFor(el),
    });
  }

  // Inside a web component e.target is the host, not the thing that was
  // clicked. The composed path starts at the real element.
  function deepTarget(e) {
    const path = e.composedPath ? e.composedPath() : null;
    return path && path.length ? path[0] : e.target;
  }

  function rectOf(el) {
    const r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    return r && r.width && r.height
      ? { left: r.left, top: r.top, width: r.width, height: r.height }
      : null;
  }

  function send(hit) {
    if (isTop) return report(hit);
    try {
      window.parent.postMessage({ __myscribe: FORWARD, hit }, '*');
    } catch {}
  }

  function onFrameMessage(e) {
    const d = e.data;
    if (!d || d.__myscribe !== FORWARD) return;
    if (d.relay) return post(d.relay); // draft from a child frame, no geometry
    if (!d.hit) return;
    const frame = frameFor(e.source);
    if (!frame) return;

    const box = frame.getBoundingClientRect();
    const cs = getComputedStyle(frame);

    // getBoundingClientRect is post-transform while offsetWidth is not, so
    // their ratio is whatever scaling the page applied to the frame.
    const sx = frame.offsetWidth ? box.width / frame.offsetWidth : 1;
    const sy = frame.offsetHeight ? box.height / frame.offsetHeight : 1;
    const ox = box.left + ((parseFloat(cs.borderLeftWidth) || 0) + (parseFloat(cs.paddingLeft) || 0)) * sx;
    const oy = box.top + ((parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.paddingTop) || 0)) * sy;

    const hit = { ...d.hit, x: d.hit.x * sx + ox, y: d.hit.y * sy + oy };
    if (hit.rect) {
      hit.rect = {
        left: hit.rect.left * sx + ox,
        top: hit.rect.top * sy + oy,
        width: hit.rect.width * sx,
        height: hit.rect.height * sy,
      };
    }
    send(hit); // keeps climbing when this frame is itself a child
  }

  function frameFor(source) {
    const frames = document.querySelectorAll('iframe, frame');
    for (const f of frames) {
      try {
        if (f.contentWindow === source) return f;
      } catch {}
    }
    return null;
  }

  function report(hit) {
    ask({
      type: 'ms:click',
      payload: {
        ...hit,
        viewportW: window.innerWidth,
        url: location.href,
        pageTitle: document.title,
        ts: Date.now(),
      },
    });
  }

  function post(message) {
    if (isTop) return ask(message);
    try {
      window.parent.postMessage({ __myscribe: FORWARD, relay: message }, '*');
    } catch {}
  }

  function ask(message, cb) {
    try {
      const p = webext.runtime.sendMessage(message);
      if (p && p.then) p.then((r) => cb && cb(r)).catch(() => {});
    } catch {
      // extension reloaded out from under this page
      document.removeEventListener(eventName, onDown, true);
    }
  }

  /* --- typing ------------------------------------------------------------ */

  const TEXT_INPUT = /^(text|search|email|url|tel|password|number|date|time|month|week|datetime-local)$/;

  function isTextField(el) {
    if (!el || !el.tagName) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'textarea') return true;
    if (tag === 'input') return TEXT_INPUT.test((el.type || 'text').toLowerCase());
    return el.isContentEditable === true;
  }

  // Never carry a password or a card number out of the page. The step still
  // gets recorded so the guide reads correctly, just without the secret.
  const SECRET_TOKENS = new Set([
    'current-password', 'new-password', 'cc-number', 'cc-csc', 'cc-exp',
    'cc-exp-month', 'cc-exp-year', 'one-time-code',
  ]);
  const SECRET_NAMES =
    /pass(wd|word)?|cc-?num|card-?num|cardnumber|ccnum|cvv|cvc|csc|secur(ity)?-?code|one-?time-?code|otp|secret|api-?key|token/;

  // Once a field has been secret it stays secret for the life of the page. A
  // "show password" toggle flips the input to type=text, and without this the
  // next keystroke would report the whole value — the part typed while it was
  // masked included.
  const everSecret = new WeakSet();

  function isSecret(el) {
    if (!el || !el.tagName) return false;
    if (everSecret.has(el)) return true;

    let secret = (el.type || '').toLowerCase() === 'password';
    if (!secret) {
      // autocomplete is a token list: match tokens, not substrings, so that
      // "cc-number" is caught and "cc-name" is not.
      const tokens = String(el.getAttribute('autocomplete') || '').toLowerCase().split(/\s+/);
      secret = tokens.some((t) => SECRET_TOKENS.has(t));
    }
    if (!secret) {
      secret = SECRET_NAMES.test(`${el.name || ''} ${el.id || ''}`.toLowerCase());
    }

    if (secret) everSecret.add(el);
    return secret;
  }

  function valueOf(el) {
    return el.isContentEditable ? el.innerText || '' : el.value || '';
  }

  const IDLE_MS = 900;
  const DRAFT_MS = 90;

  // While the panel is open the user should see their words appear as they
  // type them, not 900ms later when the step commits. This streams the value
  // for display only — nothing is stored, and a secret is never sent at all.
  function streamDraft(t) {
    const now = Date.now();
    const since = now - (t.drafted || 0);
    if (since < DRAFT_MS) {
      // Throttled, but the last keystrokes of a burst still have to arrive —
      // otherwise the panel sits on stale text until the step commits.
      clearTimeout(t.trail);
      t.trail = setTimeout(() => streamDraft(t), DRAFT_MS - since);
      return;
    }
    clearTimeout(t.trail);
    t.drafted = now;
    post({
      type: 'ms:draft',
      draft: {
        key: keyFor(t.el),
        label: t.label,
        secret: !!t.secret,
        text: t.secret ? '' : clean(t.value),
        length: String(t.value || '').length,
      },
    });
  }

  function clearDraft() {
    post({ type: 'ms:draft', draft: null });
  }

  function onInput(e) {
    if (!recording || !e.isTrusted) return;
    const el = deepTarget(e);
    if (!isTextField(el)) return;

    if (!typing || typing.el !== el) {
      flushTyping(false);
      typing = { el, secret: isSecret(el), label: fieldLabel(el), sent: null };
    }
    typing.value = valueOf(el);
    streamDraft(typing);

    // Commit once typing pauses, while the field is still focused and the
    // page still looks the way it did. Waiting for blur would photograph
    // whatever the next click opened instead of the text just entered.
    clearTimeout(typing.idle);
    typing.idle = setTimeout(() => commitTyping(false), IDLE_MS);
  }

  function onKeyDown(e) {
    if (!recording || !e.isTrusted || e.key !== 'Enter') return;
    if (!typing || typing.el !== deepTarget(e)) return;
    if (e.shiftKey) return; // a newline in a textarea, not a submit
    typing.value = valueOf(typing.el);
    flushTyping(true); // capture now: Enter often navigates away
  }

  function onChange(e) {
    if (!recording || !e.isTrusted) return;
    const el = deepTarget(e);
    if (!el || !el.tagName || el.tagName.toLowerCase() !== 'select') return;

    const opt = el.options && el.options[el.selectedIndex];
    const choice = clean(opt ? opt.label || opt.text : el.value);
    const label = fieldLabel(el);
    send({
      kind: 'select',
      ...caretPoint(el),
      rect: rectOf(el),
      text: choice,
      title: label ? `Select "${choice}" from the ${label} dropdown` : `Select "${choice}"`,
      targetKey: keyFor(el),
    });
  }

  function flushTyping(submitted) {
    const t = typing;
    typing = null;
    if (t) {
      clearTimeout(t.idle);
      clearTimeout(t.trail);
      clearDraft();
      commitTyping(submitted, t);
    }
  }

  // Each commit for the same field replaces the last one in the background,
  // so a long entry with pauses still ends up as a single step showing the
  // finished text.
  function commitTyping(submitted, session) {
    const t = session || typing;
    if (!t || !t.el.isConnected) return;

    const value = clean(t.value);
    if (!value && !t.secret) return; // focused and left, nothing typed

    const shown = t.secret ? '' : value;
    const stamp = `${shown}|${submitted ? 1 : 0}`;
    if (t.sent === stamp) return; // nothing new since the last commit
    t.sent = stamp;
    clearTimeout(t.trail);
    clearDraft();

    send({
      kind: 'type',
      ...caretPoint(t.el),
      rect: rectOf(t.el),
      text: shown,
      submitted: !!submitted,
      title: typeTitle(t.label, shown, t.secret, submitted),
      targetKey: keyFor(t.el),
    });
  }

  function typeTitle(label, value, secret, submitted) {
    const where = label ? ` into the ${label} field` : '';
    const head = secret ? `Enter your password${where}` : `Type "${value}"${where}`;
    return submitted ? `${head}, then press Enter` : head;
  }

  // Puts the mark where the text actually ends rather than in the middle of
  // the box, by measuring the field's own font against its value.
  function caretPoint(el) {
    const r = el.getBoundingClientRect();
    const mid = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    if (!r.width || !r.height) return mid;

    const cs = getComputedStyle(el);
    const insetL = (parseFloat(cs.borderLeftWidth) || 0) + (parseFloat(cs.paddingLeft) || 0);
    const insetR = (parseFloat(cs.borderRightWidth) || 0) + (parseFloat(cs.paddingRight) || 0);
    const start = r.left + insetL;
    const limit = r.left + r.width - insetR;

    // Measuring a secret would put its rendered width into the exported
    // coordinates, which is most of its length. Sit in the middle instead.
    if (isSecret(el)) {
      return { x: mid.x, y: mid.y };
    }

    let x = start;
    try {
      const upto = el.isContentEditable
        ? valueOf(el)
        : valueOf(el).slice(0, el.selectionEnd == null ? undefined : el.selectionEnd);
      if (upto) {
        const ctx = (caretPoint.ctx ||= document.createElement('canvas').getContext('2d'));
        ctx.font = cs.font || `${cs.fontSize} ${cs.fontFamily}`;
        x = start + ctx.measureText(upto).width - (el.scrollLeft || 0);
      }
    } catch {
      // selectionEnd throws on some input types; the field's left edge is fine
    }

    const single = el.tagName.toLowerCase() === 'input';
    return {
      x: Math.max(start, Math.min(limit, x)),
      y: single ? mid.y : Math.min(r.top + (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.lineHeight) || 18) / 2, r.top + r.height),
    };
  }

  // The name of a field, ignoring whatever has been typed into it.
  function fieldLabel(el) {
    const aria = clean(el.getAttribute('aria-label'));
    if (aria) return aria;

    const joined = labelledBy(el);
    if (joined) return joined;

    const lbl = el.labels && el.labels[0] ? clean(el.labels[0].textContent) : '';
    if (lbl) return lbl;

    return clean(el.placeholder || el.getAttribute('title') || el.name || '');
  }

  /* --- naming what was clicked ------------------------------------------ */

  const CLICKABLE =
    'a,button,summary,label,input,select,textarea,[role="button"],[role="link"],[role="tab"],' +
    '[role="menuitem"],[role="checkbox"],[role="radio"],[role="option"],[role="switch"],[onclick]';

  function resolveTarget(node) {
    let el = node && node.nodeType === 3 ? node.parentElement : node;
    if (!el || !el.getBoundingClientRect) return null;
    const hit = closestAcross(el, CLICKABLE);
    if (!hit) return el;
    // Don't let a giant clickable wrapper swallow the small thing you aimed at.
    const a = area(hit);
    const b = area(el);
    if (b > 0 && a > b * 12 && a > window.innerWidth * window.innerHeight * 0.35) return el;
    return hit;
  }

  // closest() stops at a shadow boundary; keep going up through the hosts.
  function closestAcross(el, selector) {
    let node = el;
    while (node) {
      const hit = node.closest ? node.closest(selector) : null;
      if (hit) return hit;
      const root = node.getRootNode ? node.getRootNode() : null;
      node = root && root.host ? root.host : null;
    }
    return null;
  }

  function area(el) {
    const r = el.getBoundingClientRect();
    return Math.max(0, r.width) * Math.max(0, r.height);
  }

  function titleFor(el) {
    if (!el) return 'Click on the page';
    const label = labelFor(el);
    const role = roleFor(el);
    if (label && role) return `Click the "${label}" ${role}`;
    if (label) return `Click "${label}"`;
    if (role) return `Click the ${role}`;
    return 'Click on the page';
  }

  function labelFor(el) {
    const tag = (el.tagName || '').toLowerCase();
    const type = (el.type || '').toLowerCase();
    const buttonish = /^(submit|button|reset|checkbox|radio|file|image)$/.test(type);

    // A field is named by its label. Reading its text content instead would
    // give a <select> every one of its options run together.
    if (tag === 'select' || tag === 'textarea' || (tag === 'input' && !buttonish)) {
      return fieldLabel(el);
    }

    const direct = clean(el.getAttribute && el.getAttribute('aria-label'));
    if (direct) return direct;

    const joined = labelledBy(el);
    if (joined) return joined;

    const text = clean(el.innerText || el.textContent);
    if (text) return text;

    if (tag === 'input' && clean(el.value)) return clean(el.value);

    const img = el.querySelector && el.querySelector('img[alt], [aria-label]');
    if (img) {
      const alt = clean(img.getAttribute('alt') || img.getAttribute('aria-label'));
      if (alt) return alt;
    }

    return clean(
      (el.getAttribute && (el.getAttribute('title') || el.getAttribute('placeholder') || el.getAttribute('name'))) || '',
    );
  }

  function roleFor(el) {
    const role = (el.getAttribute && el.getAttribute('role') || '').toLowerCase();
    const tag = (el.tagName || '').toLowerCase();
    const type = (el.type || '').toLowerCase();

    if (role === 'tab') return 'tab';
    if (role === 'menuitem') return 'menu item';
    if (role === 'checkbox' || type === 'checkbox') return 'checkbox';
    if (role === 'radio' || type === 'radio') return 'option';
    if (role === 'switch') return 'toggle';
    if (role === 'option') return 'option';
    if (tag === 'button' || role === 'button' || type === 'submit' || type === 'button' || type === 'reset') return 'button';
    if (tag === 'a' || role === 'link') return 'link';
    if (tag === 'select') return 'dropdown';
    if (tag === 'textarea') return 'field';
    if (tag === 'input') return 'field';
    if (tag === 'summary') return 'section';
    return '';
  }

  // aria-labelledby, resolved in the element's own root so it works inside a
  // shadow tree as well as the document.
  function labelledBy(el) {
    const by = el.getAttribute && el.getAttribute('aria-labelledby');
    if (!by) return '';
    const root = (el.getRootNode && el.getRootNode()) || document;
    const find = (id) => (root.getElementById ? root.getElementById(id) : document.getElementById(id));
    return clean(by.split(/\s+/).map(find).filter(Boolean).map((n) => clean(n.textContent)).join(' '));
  }

  function clean(s) {
    if (!s) return '';
    const out = String(s).replace(/\s+/g, ' ').trim();
    return out.length > 70 ? `${out.slice(0, 69).trimEnd()}…` : out;
  }
})();
