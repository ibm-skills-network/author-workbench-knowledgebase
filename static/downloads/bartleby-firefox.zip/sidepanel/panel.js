import {
  getState, getSteps, getGuide, getThumb, getPrefs, setPrefs, persistSteps,
  getImage, setImage, setThumb, deleteStep,
} from '../lib/store.js';
import { maskSpot } from '../lib/annotate.js';
import { isStep, countSteps, numberItems, stampedLabel } from '../lib/doc.js';

const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;
const $ = (id) => document.getElementById(id);
const send = (msg) => webext.runtime.sendMessage(msg).catch(() => null);

// The whole ordered array, sections included: the panel only draws the steps —
// sections are an editor concern and there is no screenshot to show — but it
// has to write the array back intact or a section would be shuffled to the end.
let steps = [];
let guide = {}; // only for how the steps are numbered — the panel edits none of it
let thumbs = new Map();
let recording = false;
let prefs = { livePanel: true };
let draft = null;
let pending = 0;
let undoEntry = null;
let toastTimer = null;
const known = new Set(); // ids already on screen, so only new rows animate

init();

// Listeners go on before the first await. The popup opens this panel and
// then tells the worker to start; if the worker's ms:recording lands while
// init is still reading storage, a listener registered afterwards never
// hears it and the panel sits on Standby with the badge reading REC.
function listen() {
  webext.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    switch (msg.type) {
      case 'ms:draft':
        draft = msg.draft || null;
        paintDraft();
        break;
      case 'ms:pending':
        pending += 1;
        paintPending(msg.title);
        break;
      case 'ms:stepFailed':
        pending = Math.max(0, pending - 1);
        paintPending();
        break;
      case 'ms:stepAdded':
        pending = Math.max(0, pending - 1);
        draft = null;
        stick = true; // a finished step is worth returning to the bottom for
        refresh().then(() => paint({ scroll: true }));
        break;
      case 'ms:recording':
        recording = !!msg.recording;
        if (!recording) draft = null;
        paint();
        break;
      case 'ms:cleared':
        reopen();
        break;
    }
  });

  // A different capture became the current one — switched in the editor, or
  // started fresh from the popup. Same job as a discard from this panel's
  // point of view: what it is showing is no longer what is being recorded.
  webext.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes['ms:current']) reopen();
    // The flag itself lives in storage, so this catches a start or stop
    // whether or not the worker's broadcast reached us.
    if (changes['ms:state']) {
      const next = changes['ms:state'].newValue || {};
      recording = !!next.recording;
      if (!recording) draft = null;
      paint();
    }
  });
}

async function init() {
  listen();
  [prefs] = await Promise.all([getPrefs()]);
  $('autoOpen').checked = prefs.livePanel !== false;

  await refresh();
  const state = await getState();
  recording = !!state.recording;
  const now = await send({ type: 'ms:live' });
  draft = (now && now.draft) || null;
  pending = (now && now.pending) || 0;
  paint();

  watchScroll();
  $('toggle').addEventListener('click', toggleRecording);
  $('openEditor').addEventListener('click', () => {
    webext.tabs.create({ url: webext.runtime.getURL('editor/editor.html') });
  });
  $('autoOpen').addEventListener('change', async (e) => {
    prefs = await setPrefs({ livePanel: e.target.checked });
  });
  $('toastUndo').addEventListener('click', undo);

}

function reopen() {
  known.clear();
  hideToast();
  refresh().then(() => paint());
}

async function refresh() {
  [steps, guide] = await Promise.all([getSteps(), getGuide()]);
  const missing = steps.filter((s) => !thumbs.has(s.id));
  const got = await Promise.all(missing.map((s) => getThumb(s.id)));
  missing.forEach((s, i) => thumbs.set(s.id, got[i]));
  for (const id of [...thumbs.keys()]) {
    if (!steps.some((s) => s.id === id)) thumbs.delete(id);
  }
}

async function toggleRecording() {
  if (recording) {
    await send({ type: 'ms:stop' });
    recording = false;
  } else {
    await send({ type: 'ms:start', fresh: false });
    recording = true;
  }
  paint();
}

/* ------------------------------- painting ------------------------------- */

function paint(opts = {}) {
  document.body.classList.toggle('live', recording);

  const status = $('status');
  const count = countSteps(steps);
  status.className = `status${recording ? ' live' : count ? ' ready' : ''}`;
  $('statusText').textContent = recording ? 'Recording' : count ? 'Paused' : 'Standby';
  $('count').textContent = String(count).padStart(2, '0');
  $('toggle').title = recording ? 'Stop recording' : 'Start recording';
  $('toggle').setAttribute('aria-label', $('toggle').title);

  paintSteps(opts);
  paintDraft();
  paintPending();
  paintBlank();
}

function paintBlank() {
  const empty = !countSteps(steps) && !draft && !pending;
  $('blank').hidden = !empty;
  if (!empty) return;
  $('blankTitle').textContent = recording ? 'Listening' : 'Ready when you are';
  $('blankBody').textContent = recording
    ? 'Click something or fill in a field. It shows up here the moment you do.'
    : 'Press record and work through your flow. Steps land here as you go, and you can fix the wording without leaving the page.';
}

function paintSteps({ scroll = false } = {}) {
  const list = $('steps');
  const tpl = $('stepTpl');
  const focus = rememberFocus();
  list.textContent = '';

  numberItems(steps, guide).forEach(({ item: step, label }) => {
    if (!isStep(step)) return;
    const kind = step.kind;
    const node = tpl.content.firstElementChild.cloneNode(true);
    node.dataset.kind = kind;
    node.id = `p-${step.id}`;
    if (!known.has(step.id)) node.classList.add('fresh');

    node.querySelector('.num').textContent = label.length === 1 ? `0${label}` : label;
    node.querySelector('.kind').textContent = kind;

    const title = node.querySelector('.title');
    title.value = step.title;
    title.dataset.fkey = `${step.id}:title`;
    title.setAttribute('aria-label', `Step ${label} title`);
    bind(title, (v) => save(step.id, { title: v }));

    const typed = node.querySelector('.typed');
    if (kind === 'type' || kind === 'select') {
      typed.hidden = false;
      const input = typed.querySelector('.typed-input');
      typed.querySelector('.typed-label').textContent = kind === 'select' ? 'Chose' : 'Typed';
      input.dataset.fkey = `${step.id}:text`;
      input.setAttribute('aria-label', `Value captured in step ${label}`);
      if (step.text) {
        input.value = step.text;
        bind(input, (v) => saveValue(step.id, v));
      } else {
        input.value = 'not recorded';
        input.readOnly = true;
      }
    } else {
      typed.remove();
    }

    const note = node.querySelector('.note');
    note.value = step.note || '';
    note.dataset.fkey = `${step.id}:note`;
    note.setAttribute('aria-label', `Note for step ${label}`);
    bind(note, (v) => save(step.id, { note: v }));

    const redact = node.querySelector('.redact');
    if (step.text) {
      redact.setAttribute('aria-label', `Redact the value in step ${label}`);
      redact.addEventListener('click', () => redactStep(step.id));
    } else {
      redact.remove();
    }

    const del = node.querySelector('.del');
    del.setAttribute('aria-label', `Delete step ${label}`);
    del.addEventListener('click', () => remove(step.id));

    const shot = node.querySelector('.shot');
    const thumb = thumbs.get(step.id);
    if (thumb) {
      shot.querySelector('img').src = thumb;
      shot.setAttribute('aria-label', `Screenshot for step ${label}, opens the full editor`);
      shot.addEventListener('click', () => {
        webext.tabs.create({ url: webext.runtime.getURL(`editor/editor.html#step-${step.id}`) });
      });
    } else {
      shot.remove();
    }

    list.append(node);
    known.add(step.id);
  });

  restoreFocus(focus);
  autosizeAll();
  if (scroll) scrollToEnd();
}

function paintDraft() {
  const box = $('draft');
  if (!draft) {
    box.hidden = true;
    paintBlank();
    return;
  }
  box.hidden = false;
  $('draftLabel').textContent = draft.label ? `Typing · ${draft.label}` : 'Typing';
  $('draftText').textContent = draft.secret
    ? '•'.repeat(Math.min(draft.length || 0, 32))
    : draft.text || '';
  paintBlank();
  scrollToEnd();
}

function paintPending(title) {
  const box = $('pending');
  box.hidden = pending <= 0;
  if (pending > 0) {
    $('pendingText').textContent = title ? `Capturing · ${title}` : 'Capturing…';
    scrollToEnd();
  }
  paintBlank();
}

// The feed follows the newest step, but only while the reader is already at the
// bottom. Scrolling up to re-read an earlier step must not be undone by the
// next keystroke.
let stick = true;

function watchScroll() {
  const feed = $('feed');
  feed.addEventListener('scroll', () => {
    stick = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 60;
  }, { passive: true });
}

function scrollToEnd() {
  if (!stick) return;
  const feed = $('feed');
  feed.scrollTo({ top: feed.scrollHeight, behavior: prefersMotion() ? 'smooth' : 'auto' });
}

const prefersMotion = () => !window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* -------------------------------- editing ------------------------------- */

// A step arriving mid-edit rebuilds the list under the cursor. The debounce
// below closes over its own element, so a pending write still lands even after
// that element is detached — and rememberFocus/restoreFocus carry the caret
// and the unsaved text across to the new one.
function bind(el, save) {
  let timer;
  const flush = () => {
    clearTimeout(timer);
    save(el.value);
  };

  el.addEventListener('input', () => {
    autosize(el);
    clearTimeout(timer);
    timer = setTimeout(flush, 350);
  });
  el.addEventListener('blur', flush);
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && el.tagName === 'TEXTAREA' && el.classList.contains('title')) {
      e.preventDefault();
      el.blur();
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      el.blur();
    }
  });
}

async function save(id, patch) {
  const step = steps.find((s) => s.id === id);
  if (!step) return;
  if (Object.entries(patch).every(([k, v]) => step[k] === v)) return;
  Object.assign(step, patch);
  const { arrivals } = await persistSteps(steps);
  if (arrivals) {
    await refresh();
    paint();
  }
}

// Correcting the captured value rewrites the same string inside the title, so
// fixing a typo (or a secret) is one edit rather than two.
async function saveValue(id, next) {
  const step = steps.find((s) => s.id === id);
  if (!step || next === step.text) return;
  const prev = step.text || '';
  if (prev && step.title) step.title = swapValue(step.title, prev, next);
  step.text = next;
  const { arrivals } = await persistSteps(steps);
  await refresh();
  paint();
  if (arrivals) return;
  const el = document.querySelector(`[data-fkey="${id}:title"]`);
  if (el) el.value = step.title;
}

function swapValue(title, from, to) {
  const quoted = `"${from}"`;
  const at = title.indexOf(quoted);
  if (at >= 0) return `${title.slice(0, at)}"${to}"${title.slice(at + quoted.length)}`;
  const i = title.indexOf(from);
  return i < 0 ? title : title.slice(0, i) + to + title.slice(i + from.length);
}

async function redactStep(id) {
  const step = steps.find((s) => s.id === id);
  if (!step) return;
  const shot = await getImage(id);
  const masked = shot && step.spot ? await maskSpot(shot, step.spot, step.badge, stampedLabel(step)) : null;
  if (masked) {
    await setImage(id, masked.image);
    await setThumb(id, masked.thumb);
    thumbs.delete(id);
  }
  if (step.text && step.title) step.title = swapValue(step.title, step.text, '••••••');
  step.text = '';
  await persistSteps(steps);
  undoEntry = null; // an undo could put the value back
  hideToast();
  await refresh();
  paint();
  toast(masked ? 'Value painted out' : 'Text redacted only', { undoable: false });
}

async function remove(id) {
  const step = steps.find((s) => s.id === id);
  if (!step) return;
  const at = steps.indexOf(step);
  const [image, thumb] = await Promise.all([getImage(id), getThumb(id)]);

  steps = steps.filter((s) => s.id !== id);
  known.delete(id);
  thumbs.delete(id);
  await deleteStep(id);
  await renumber([id]);

  undoEntry = { step: { ...step }, at, image, thumb };
  toast('Step deleted', { undoable: true });
}

async function undo() {
  const entry = undoEntry;
  undoEntry = null;
  hideToast();
  if (!entry) return;

  steps.splice(Math.min(entry.at, steps.length), 0, entry.step);
  if (entry.image) await setImage(entry.step.id, entry.image);
  if (entry.thumb) await setThumb(entry.step.id, entry.thumb);
  await renumber();
  await refresh();
  paint();
}

// Positions changed, and the number is baked into each screenshot.
async function renumber(removedIds) {
  const { restamp } = await import('../lib/annotate.js');
  for (const { item: step, n, label } of numberItems(steps, guide)) {
    if (label == null || stampedLabel(step) === label) continue;
    if (step.badge) {
      const shot = await getImage(step.id);
      if (shot) {
        const out = await restamp(shot, step.badge, label);
        await setImage(step.id, out.image);
        await setThumb(step.id, out.thumb);
        thumbs.delete(step.id);
      }
    }
    step.n = n;
    step.label = label;
  }
  await persistSteps(steps, removedIds);
  await refresh();
  paint();
  send({ type: 'ms:refreshBadge' });
}

/* -------------------------------- chrome -------------------------------- */

function toast(text, { undoable }) {
  clearTimeout(toastTimer);
  $('toastText').textContent = text;
  $('toastUndo').hidden = !undoable;
  $('toast').hidden = false;
  toastTimer = setTimeout(hideToast, 6000);
}

function hideToast() {
  clearTimeout(toastTimer);
  $('toast').hidden = true;
}

function rememberFocus() {
  const el = document.activeElement;
  if (!el || !el.dataset || !el.dataset.fkey) return null;
  return { key: el.dataset.fkey, start: el.selectionStart, end: el.selectionEnd, value: el.value };
}

function restoreFocus(snap) {
  if (!snap) return;
  const el = document.querySelector(`[data-fkey="${snap.key}"]`);
  if (!el) return;
  el.value = snap.value; // keep what was being typed, unsaved and all
  el.focus();
  try {
    el.setSelectionRange(snap.start, snap.end);
  } catch {}
}

function autosize(el) {
  if (el.tagName !== 'TEXTAREA') return;
  el.style.height = 'auto';
  el.style.height = `${el.scrollHeight}px`;
}

function autosizeAll() {
  document.querySelectorAll('textarea').forEach(autosize);
}
