import { renderStep, MARK } from './lib/annotate.js';
import {
  getState, setState, getSteps, appendStep, deleteStep, getGuide, setGuide,
  clearAll, sweepOrphans, getPrefs, getImages, createSession,
} from './lib/store.js';
import { buildLabMarkdown, labUrl, awbContext, AWB_ORIGINS } from './lib/awb.js';
import { countSteps, nextNumber, stampedLabel } from './lib/doc.js';

const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;
const CAPTURE_GAP_MS = 550; // Chromium allows 2 captureVisibleTab calls per second

let captureChain = Promise.resolve();
let writeChain = Promise.resolve();
let lastCaptureAt = 0;

// What the live panel needs to show right now. Held in memory on purpose: it
// is display state for the current keystroke, not something to persist.
let live = { draft: null, pending: 0 };

webext.runtime.onInstalled.addListener(() => resetRecording());
webext.runtime.onStartup.addListener(() => resetRecording());

async function resetRecording() {
  await setState({ recording: false });
  await refreshBadge();
  // Once per browser session, off the hot path: a screenshot whose step is
  // gone is invisible in the UI but still on disk.
  const swept = await sweepOrphans();
  if (swept) console.info(`[Bartleby] cleared ${swept} orphaned screenshot key(s)`);
}

webext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;

  switch (msg.type) {
    case 'ms:getState':
      (async () => {
        const [state, steps] = await Promise.all([getState(), getSteps()]);
        sendResponse({
          recording: !!state.recording,
          count: countSteps(steps),
          startedAt: state.startedAt,
        });
      })();
      return true;

    // What a surface needs to decide whether there is anything to send, without
    // a network round trip. The in-page launcher asks for this on every AWB
    // page load, so it stays cheap.
    case 'ms:brief':
      return respond(sendResponse, async () => {
        const [state, steps, guide] = await Promise.all([getState(), getSteps(), getGuide()]);
        const count = countSteps(steps);
        return {
          recording: !!state.recording,
          count,
          sections: steps.length - count,
          title: guide.title || '',
          awb: guide.awb || null,
        };
      });

    case 'ms:start':
      (async () => {
        // "Start a new capture" now means a new one beside the old, not on top
        // of it. The surfaces that are showing the old one hear about it from
        // extension storage rather than from here: which capture is current is a
        // fact about storage, and every page already has to watch for it
        // changing in another tab.
        if (msg.fresh) await createSession();
        const guide = await getGuide();
        if (!guide.createdAt) await setGuide({ createdAt: Date.now() });
        live = { draft: null, pending: 0 };
        await setState({ recording: true, startedAt: Date.now() });
        await injectExisting();
        await broadcastRecording(true);
        await refreshBadge();
        sendResponse({ ok: true });
      })();
      return true;

    case 'ms:stop':
      (async () => {
        live = { draft: null, pending: 0 };
        notify({ type: 'ms:draft', draft: null });
        await setState({ recording: false });
        await broadcastRecording(false);
        await refreshBadge();
        sendResponse({ ok: true });
      })();
      return true;

    case 'ms:discard':
      (async () => {
        await clearAll();
        notify({ type: 'ms:cleared' });
        await setState({ recording: false });
        await broadcastRecording(false);
        await refreshBadge();
        sendResponse({ ok: true });
      })();
      return true;

    case 'ms:click':
      handleClick(msg.payload, sender);
      return false;

    case 'ms:draft':
      live.draft = msg.draft || null;
      notify({ type: 'ms:draft', draft: live.draft });
      return false;

    // A panel that opens mid-session needs whatever is in flight right now.
    case 'ms:live':
      sendResponse(live);
      return false;

    case 'ms:openPanel':
      openPanel(msg.windowId).then(() => sendResponse({ ok: true }), () => sendResponse({ ok: false }));
      return true;

    case 'ms:refreshBadge':
      refreshBadge();
      return false;

    /* --- Author Workbench ------------------------------------------------ */

    // The popup and the editor send people to the card on an Author Workbench
    // page: the tab under the popup, an open one, or a new one.
    case 'ms:openWorkbench':
      return respond(sendResponse, () => openWorkbench(msg.origin, msg.tabId));

    // Everything the launcher drawn on the AWB page needs to fill itself in:
    // where it is and what there is to send.
    case 'awb:brief':
      return respond(sendResponse, () => awbBrief(msg.url || (sender.tab && sender.tab.url)));

    // The lab's name, read off its page on the AWB tab that asked.
    case 'awb:lab':
      return respond(sendResponse, async () => {
        const tabId = senderAwbTab(sender) || (await findAwbTab(msg.origin));
        if (!tabId) return { labId: msg.labId, name: null };
        return askAwbTab(tabId, { type: 'awb:lab', labId: msg.labId });
      });

    // The launcher on the page doesn't know its own tab id; the sender does.
    case 'awb:push':
      return respond(sendResponse, () => awbPush({ ...msg, tabId: msg.tabId || senderAwbTab(sender) }));
  }
});

// The sender's tab, if it is an Author Workbench tab. Extension pages are tabs
// too, and none of them can write a lab.
const senderAwbTab = (sender) =>
  sender && sender.tab && awbContext(sender.tab.url) ? sender.tab.id : null;

// Every awb:* handler answers the same shape, so the publish page has one
// place to turn a failure into a line the user can act on. Errors don't
// survive sendMessage as errors, so the code travels beside the message.
function respond(sendResponse, work) {
  Promise.resolve()
    .then(work)
    .then(
      (value) => sendResponse({ ok: true, value }),
      (err) => sendResponse({ ok: false, error: (err && err.message) || String(err), code: (err && err.code) || 'awb/failed' }),
    );
  return true;
}

function handleClick(payload, sender) {
  const tab = sender && sender.tab;
  if (!tab || typeof tab.windowId !== 'number') return;

  // Settle "was this recording?" now, against the moment the interaction was
  // reported. Asking after the capture resolves would throw away clicks the
  // user really made, because a queued capture can be waiting out the rate
  // limit when they reach for Stop.
  const wasRecording = getState().then((s) => !!s.recording);

  // Tell the panel immediately. The screenshot is a few hundred milliseconds
  // away, and a row that appears the moment you click reads as responsive
  // where one that waits for the image reads as broken.
  if (payload.kind === 'click') {
    live.pending += 1;
    notify({ type: 'ms:pending', title: payload.title, kind: payload.kind });
  }

  const capture = captureChain.then(
    () => captureVisible(tab.windowId),
    () => captureVisible(tab.windowId),
  );
  captureChain = capture.catch(() => {});

  writeChain = writeChain
    .then(() => capture)
    .then(async (dataUrl) => {
      if (!dataUrl) return;
      if (!(await wasRecording)) return; // the click landed after Stop

      let steps = await getSteps();

      // Clicking a field and then filling it in is one instruction, not two —
      // and the later screenshot is the better one because it shows the value.
      // So typing (or picking an option) folds into the click that opened it.
      const prev = steps[steps.length - 1];
      const folds =
        (payload.kind === 'type' || payload.kind === 'select') &&
        prev &&
        prev.key &&
        prev.key === payload.targetKey &&
        prev.url === payload.url;

      // A fold keeps the number the step already has; anything else is
      // numbered by the same rules the editor uses, so a capture with restarted
      // numbering keeps counting the way the author set it up.
      const guide = await getGuide();
      const kept = folds ? { n: prev.n, label: stampedLabel(prev) } : nextNumber(steps, guide);
      const { n, label } = kept;
      const rendered = await renderStep(dataUrl, { ...payload, n, label });

      // A fold keeps the step's identity. Minting a new id would drop any edit
      // someone had in flight against it in the live panel, and would make the
      // panel throw the row away and animate a replacement in its place.
      const id = folds ? prev.id : `${Date.now().toString(36)}-${countSteps(steps) + 1}`;
      if (folds) steps = await deleteStep(prev.id);

      await appendStep(
        {
          id,
          n,
          label,
          kind: payload.kind || 'click',
          title: payload.title,
          note: folds ? prev.note || '' : '',
          text: payload.text || '',
          submitted: !!payload.submitted,
          key: payload.targetKey || null,
          url: payload.url,
          ts: payload.ts,
          width: rendered.width,
          height: rendered.height,
          badge: rendered.badge,
          spot: rendered.spot,
        },
        rendered.image,
        rendered.thumb,
      );

      // The count is the number of steps, which is no longer the same thing as
      // the last step's number once numbering has been restarted.
      const total = countSteps(steps) + 1;
      if (total === 1 && !guide.title) await setGuide({ title: defaultTitle(payload) });
      await refreshBadge();
      live.pending = Math.max(0, live.pending - (payload.kind === 'click' ? 1 : 0));
      notify({ type: 'ms:stepAdded', count: total, folded: folds });
    })
    .catch((err) => {
      live.pending = Math.max(0, live.pending - (payload.kind === 'click' ? 1 : 0));
      notify({ type: 'ms:stepFailed' });
      console.warn('[Bartleby] could not save step:', err && err.message);
    });
}

// Tabs opened before the extension was installed (or before this session)
// have no content script yet. Give them one so recording works right away
// instead of only after a reload.
// The panel is browser UI rather than page content, which is why it is a side
// panel and not an injected overlay: captureVisibleTab photographs the tab, so
// an in-page panel would appear in every screenshot it is meant to describe.
async function openPanel(windowId) {
  if (webext.sidebarAction?.open) {
    await webext.sidebarAction.open();
    return;
  }
  if (!webext.sidePanel?.open) return;
  const id = windowId ?? (await webext.windows.getCurrent()).id;
  await webext.sidePanel.open({ windowId: id });
}

async function injectExisting() {
  const tabs = await webext.tabs.query({});
  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id || !/^(https?|file):/.test(tab.url || '')) return;
      try {
        await webext.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['content.js'],
        });
      } catch {
        // restricted page (web store, chrome://, another extension) — skip it
      }
    }),
  );
}

async function captureVisible(windowId) {
  const wait = CAPTURE_GAP_MS - (Date.now() - lastCaptureAt);
  if (wait > 0) await sleep(wait);
  lastCaptureAt = Date.now();
  try {
    return await webext.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
  } catch (err) {
    // Almost always the per-second quota; one retry clears it.
    await sleep(CAPTURE_GAP_MS + 120);
    lastCaptureAt = Date.now();
    try {
      return await webext.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 92 });
    } catch (err2) {
      console.warn('[Bartleby] screenshot failed:', err2 && err2.message);
      return null;
    }
  }
}

function defaultTitle(payload) {
  const base = (payload.pageTitle || '').trim().split(/\s+[|–—-]\s+/)[0];
  if (base) return `How to: ${base.slice(0, 60)}`;
  try {
    return `How to: ${new URL(payload.url).hostname.replace(/^www\./, '')}`;
  } catch {
    return 'Untitled guide';
  }
}

async function broadcastRecording(recording) {
  const tabs = await webext.tabs.query({});
  await Promise.all(
    tabs.map((t) =>
      webext.tabs.sendMessage(t.id, { type: 'ms:recording', recording }).catch(() => {}),
    ),
  );
  notify({ type: 'ms:recording', recording });
}

function notify(msg) {
  webext.runtime.sendMessage(msg).catch(() => {}); // no popup open is fine
}

async function refreshBadge() {
  const [state, steps] = await Promise.all([getState(), getSteps()]);
  if (state.recording) {
    await webext.action.setBadgeBackgroundColor({ color: MARK });
    await webext.action.setBadgeText({ text: 'REC' });
  } else {
    const count = countSteps(steps);
    await webext.action.setBadgeBackgroundColor({ color: '#5A6472' });
    await webext.action.setBadgeText({ text: count ? String(count) : '' });
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ------------------------- Author Workbench ------------------------------ */

// Everything AWB-side runs on an Author Workbench tab, as the signed-in author.
// A tab that was open before the extension was installed has no content script,
// so inject one and ask again rather than failing on a reload the user
// shouldn't have to think about.
async function askAwbTab(tabId, msg) {
  let res;
  try {
    res = await webext.tabs.sendMessage(tabId, msg);
  } catch {
    await webext.scripting.executeScript({ target: { tabId }, files: ['awb/page.js'] });
    res = await webext.tabs.sendMessage(tabId, msg);
  }
  if (!res) throw new Error('the Author Workbench tab did not answer — try reloading it');
  if (!res.ok) throw new Error(res.error);
  return res.value;
}

// An open tab on this host, if there is one. Any page will do for writing:
// the session cookie is the same everywhere on the origin.
async function findAwbTab(origin) {
  if (!origin) return null;
  const open = await webext.tabs.query({ url: `${origin}/*` }).catch(() => []);
  const pick = open.find((t) => t.active) || open[0];
  return pick ? pick.id : null;
}

// Opens a tab and waits for it to finish loading, so the content script is
// there to answer.
async function openTab(url) {
  const tab = await webext.tabs.create({ url, active: true });
  await new Promise((resolve) => {
    const finish = () => {
      webext.tabs.onUpdated.removeListener(onUpdated);
      clearTimeout(timer);
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id === tab.id && info.status === 'complete') finish();
    };
    const timer = setTimeout(finish, 15000);
    webext.tabs.onUpdated.addListener(onUpdated);
  });
  return tab.id;
}

// Takes the author to the card: the AWB tab they named, else an open one on
// the host, else a new one — the lab this capture last went to, if there is
// one, so the card opens ready to update it. Then opens the card there.
async function openWorkbench(origin, tabId) {
  const guide = await getGuide();
  const memory = guide.awb || null;
  const target = origin || (memory && memory.origin) || AWB_ORIGINS[0];

  if (!tabId) tabId = await findAwbTab(target);
  if (!tabId) {
    const url = memory && memory.origin === target && memory.labId ? `${target}/labs/${memory.labId}` : `${target}/`;
    tabId = await openTab(url);
  }

  // Bringing the tab forward is a courtesy; opening the card is the point, so
  // a tab strip that cannot be touched right now does not stop it.
  const tab = await webext.tabs.update(tabId, { active: true }).catch(() => null);
  if (tab && typeof tab.windowId === 'number') {
    await webext.windows.update(tab.windowId, { focused: true }).catch(() => {});
  }

  // The content script arrives at document_idle, and a tab that was open before
  // the extension was installed has none: ask, inject if need be, ask again.
  for (let attempt = 0; attempt < 40; attempt++) {
    try {
      const res = await webext.tabs.sendMessage(tabId, { type: 'ms:openCard' });
      if (res && res.ok) return { tabId };
    } catch {
      if (attempt === 4) {
        await webext.scripting.executeScript({ target: { tabId }, files: ['awb/page.js', 'awb/inpage.js'] }).catch(() => {});
      }
    }
    await sleep(250);
  }
  throw new Error('Author Workbench opened, but the card did not appear — reload the tab and try again.');
}

// The launcher and the popup both want to know, before they draw anything,
// what there is to send and where it went last time. Local reads only: an AWB
// page load must not put a request on the wire.
async function awbBrief(url) {
  const context = awbContext(url);
  const [state, steps, guide] = await Promise.all([getState(), getSteps(), getGuide()]);
  const count = countSteps(steps);
  return {
    context,
    recording: !!state.recording,
    count,
    sections: steps.length - count,
    title: guide.title || '',
    awb: guide.awb || null,
  };
}

async function awbPush({ mode, origin, tabId, container, name, description, labId, changelog, publish }) {
  // Extension pages hear this over runtime messaging; a launcher drawn on the
  // page is a content script and only hears what is sent to its tab.
  const say = (text) => {
    notify({ type: 'awb:progress', text });
    if (tabId) webext.tabs.sendMessage(tabId, { type: 'awb:progress', text }).catch(() => {});
  };

  say('reading the capture');
  const [guide, steps] = await Promise.all([getGuide(), getSteps()]);
  if (!steps.length) throw new Error('There are no steps to send yet.');
  const images = await getImages(steps.map((s) => s.id));
  const markdown = buildLabMarkdown({ guide, steps, images });

  // Everything happens on the Author Workbench tab the card is drawn on. The
  // page it is on is the context: a course page attaches the new lab there.
  if (!tabId) throw new Error('Open Author Workbench in a tab — the push runs from the page you are on.');
  if (mode !== 'create' && !labId) throw new Error('No lab id — pick a lab to update.');

  let created = false;
  let attached = false;
  if (mode === 'create') {
    const title = (name || guide.title || 'Untitled lab').trim();
    say(container ? `creating the lab in ${container.labableType} ${container.labableId}` : 'creating the lab');
    const res = await askAwbTab(tabId, { type: 'awb:createLab', name: title, description, container });
    labId = res.labId;
    attached = res.attached;
    created = true;
    say(`lab ${labId} created${attached ? ' and attached' : ''}`);

    // Remember it now, before the content goes anywhere. If writing the
    // instructions fails the lab still exists, and a retry has to update that
    // one rather than create a second empty lab.
    await rememberLab(origin, labId);
  }

  say(publish ? 'writing and publishing the draft' : 'writing the draft');
  const draft = await askAwbTab(tabId, { type: 'awb:writeDraft', labId, markdown, changelog, publish: !!publish });

  await rememberLab(origin, labId);

  return {
    labId,
    versionId: draft.lab_version_id,
    images: images.filter(Boolean).length,
    created,
    attached,
    url: labUrl(origin, labId),
    publish: !!draft.published,
  };
}

// Where this capture landed, so the next push updates that lab rather than
// quietly creating a second copy of the same guide.
async function rememberLab(origin, labId) {
  await setGuide({ awb: { origin, labId: String(labId), pushedAt: Date.now() } });
}
