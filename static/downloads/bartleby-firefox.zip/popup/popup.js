import { getPrefs, setPrefs } from '../lib/store.js';
import { awbContext, containerLabel, AWB_ORIGINS } from '../lib/awb.js';

const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;
const $ = (id) => document.getElementById(id);
const send = (msg) => webext.runtime.sendMessage(msg).catch(() => null);

let state = { recording: false, count: 0, startedAt: null };
let prefs = { livePanel: true };
let pending = false; // the discard confirmation is showing
let ticker = null;
let awb = null; // the AWB tab under the popup, if this is one
let brief = null; // count and remembered lab, once asked for
let opening = false; // Author Workbench is being opened

init();

async function init() {
  const [res, p] = await Promise.all([send({ type: 'ms:getState' }), getPrefs(), readAwbTab()]);
  if (res) state = res;
  prefs = p;
  $('livePanel').checked = prefs.livePanel !== false;
  render();

  $('livePanel').addEventListener('change', async (e) => {
    // Keep the sidebar call inside the user gesture in Firefox. Awaiting the
    // preference write first would make Firefox reject sidebarAction.open().
    if (e.target.checked && state.recording) await openPanel();
    prefs = await setPrefs({ livePanel: e.target.checked });
    render();
  });

  $('record').addEventListener('click', toggle);
  $('review').addEventListener('click', (e) => {
    e.preventDefault();
    webext.tabs.create({ url: webext.runtime.getURL('editor/editor.html') });
    window.close();
  });
  $('awbSend').addEventListener('click', openWorkbench);

  // The on-page card can be switched off from itself, so this is the way back.
  $('awbLauncher').addEventListener('click', async () => {
    prefs = await setPrefs({ pageLauncher: true });
    if (awb) webext.tabs.sendMessage(awb.tabId, { type: 'ms:launcher', on: true }).catch(() => {});
    render();
  });
  $('discard').addEventListener('click', () => {
    pending = true;
    render();
  });
  // A new capture is now one beside this one rather than one on top of it,
  // so there is nothing to warn about and nothing to confirm.
  $('fresh').addEventListener('click', startFresh);
  $('cancel').addEventListener('click', () => {
    pending = false;
    render();
  });
  $('confirmOk').addEventListener('click', runConfirm);

  webext.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'ms:stepAdded') state.count = msg.count;
    if (msg.type === 'ms:recording') state.recording = msg.recording;
    render();
  });

  refreshBrief();
}

async function toggle() {
  if (state.recording) {
    await send({ type: 'ms:stop' });
    state.recording = false;
  } else {
    // Open the panel from this click. The panel API needs a user
    // gesture, and the popup has one; the service worker does not.
    if (prefs.livePanel !== false) await openPanel();
    await send({ type: 'ms:start', fresh: false });
    state.recording = true;
    state.startedAt = Date.now();
  }
  pending = false;
  render();
}

async function openPanel() {
  try {
    // Firefox requires sidebarAction.open() to run directly from the click.
    if (webext.sidebarAction?.open) {
      await webext.sidebarAction.open();
      return;
    }
    const win = await webext.windows.getCurrent();
    await webext.sidePanel.open({ windowId: win.id });
  } catch (err) {
    // The browser refuses without a gesture, or the API is missing on this build.
    console.warn('[Bartleby] could not open the live panel:', err && err.message);
  }
}

async function runConfirm() {
  pending = false;
  await send({ type: 'ms:discard' });
  state = { recording: false, count: 0, startedAt: null };
  brief = null;
  render();
  await refreshBrief();
}

async function startFresh() {
  if (prefs.livePanel !== false) await openPanel();
  await send({ type: 'ms:start', fresh: true });
  state = { recording: true, count: 0, startedAt: Date.now() };
  brief = null;
  pending = false;
  render();
  await refreshBrief();
}

function render() {
  const { recording, count } = state;
  document.body.classList.toggle('live', recording);

  const status = $('status');
  status.className = `status${recording ? ' live' : count ? ' ready' : ''}`;
  $('statusText').textContent = recording ? 'Recording' : count ? 'Ready' : 'Standby';

  $('action').textContent = recording
    ? 'Stop recording'
    : count
      ? 'Resume recording'
      : 'Start recording';

  $('hint').textContent = recording
    ? 'Captured in every tab. Stop when your flow is done.'
    : count
      ? 'Add more steps, or take it to the editor.'
      : 'Every click and every field you fill in becomes a step.';

  $('record').setAttribute('aria-label', $('action').textContent);
  $('count').textContent = String(count).padStart(2, '0');

  $('panelNote').textContent = prefs.livePanel === false
    ? 'Off — record without the side panel'
    : 'Opens beside the page while you record';

  renderAwb();

  // Shown with nothing recorded too: the editor is where the captures are
  // listed, and an empty capture is exactly when you want to reach one of
  // the others. Only the two buttons that act on content come and go.
  $('foot').hidden = recording || pending;
  $('capture').textContent = captureLine();
  $('capture').title = (brief && brief.title) || '';
  $('fresh').hidden = !count;
  $('discard').hidden = !count;

  const confirming = pending;
  $('confirm').hidden = !confirming;
  if (confirming) {
    const label = `${count} step${count === 1 ? '' : 's'}`;
    $('confirmText').textContent = `Discard ${label}? This can't be undone.`;
    $('confirmOk').textContent = 'Discard';
  }

  clearInterval(ticker);
  if (recording && state.startedAt) {
    tick();
    ticker = setInterval(tick, 1000);
  } else {
    $('elapsed').textContent = '--:--';
  }
}

// The capture the buttons above act on. Its title if it has one, and
// otherwise what it is: the empty one waiting to be recorded into.
function captureLine() {
  const title = (brief && brief.title || '').trim();
  if (title) return title;
  return state.count ? 'Untitled capture' : 'New capture';
}

function tick() {
  const s = Math.max(0, Math.floor((Date.now() - state.startedAt) / 1000));
  const mm = String(Math.floor(s / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  $('elapsed').textContent = `${mm}:${ss}`;
}

/* --- Author Workbench ---------------------------------------------------- */

// The card appears whenever there is something recorded. Pushing itself
// happens on an Author Workbench tab, in the card drawn on the page; this
// button takes you there — to the tab under the popup if it is one, to an open
// one otherwise, and to a new one if there is none.
async function readAwbTab() {
  try {
    const [tab] = await webext.tabs.query({ active: true, currentWindow: true });
    const context = tab && awbContext(tab.url);
    if (context) awb = { tabId: tab.id, ...context };
  } catch {
    // no tabs permission on this surface, or nothing active — leave it off
  }
}

// Deliberately the local-only brief: opening the popup must not put a request
// on the wire.
async function refreshBrief() {
  const res = await send({ type: 'ms:brief' });
  if (res && res.ok) brief = res.value;
  render();
}

const remembered = () => (brief && brief.awb) || null;
const targetOrigin = () =>
  (awb && awb.origin) || (remembered() && remembered().origin) || AWB_ORIGINS[0];

// Which lab an update would land in: the one you're looking at, else the one
// this capture was last pushed to.
function knownLab() {
  if (awb && awb.labId) return awb.labId;
  const memory = remembered();
  if (memory && memory.origin === targetOrigin()) return memory.labId;
  return null;
}

function renderAwb() {
  const { count } = state;
  const card = $('awb');
  card.hidden = !count && !awb;
  if (card.hidden) return;

  const origin = targetOrigin();
  $('awbHost').textContent = new URL(origin).host;

  const lab = knownLab();
  const label = `${count} step${count === 1 ? '' : 's'}`;
  const context = $('awbCtx');
  if (!count) {
    context.textContent = 'Record a flow and it becomes the lab instructions.';
  } else if (awb && awb.container) {
    setChipSentence(context, `Send ${label} as a lab in `, containerLabel(awb.container), '.');
  } else if (lab) {
    setChipSentence(context, `Send ${label} to `, `Lab ${lab}`, ', or as a new lab.');
  } else {
    context.textContent = `Send ${label} as a new lab.`;
  }

  $('awbSend').disabled = opening || !count;
  $('awbSend').textContent = awb ? 'Send to Workbench' : `Open ${new URL(origin).host}`;
  $('awbLauncher').hidden = !awb || prefs.pageLauncher !== false;
}

async function openWorkbench() {
  if (opening) return;
  opening = true;
  setAwbState(awb ? 'opening the card…' : 'opening Author Workbench…');
  render();

  const res = await send({ type: 'ms:openWorkbench', origin: targetOrigin(), tabId: awb ? awb.tabId : null });
  opening = false;

  if (!res || !res.ok) {
    setAwbState((res && res.error) || 'could not open Author Workbench', 'bad');
    render();
    return;
  }
  window.close();
}

function setAwbState(text, kind) {
  const el = $('awbState');
  el.hidden = !text;
  el.textContent = text || '';
  el.className = `awb-state${kind ? ` ${kind}` : ''}`;
}

function setChipSentence(element, before, chipText, after) {
  const chip = document.createElement('span');
  chip.className = 'chip';
  chip.textContent = chipText;
  element.replaceChildren(document.createTextNode(before), chip, document.createTextNode(after));
}
