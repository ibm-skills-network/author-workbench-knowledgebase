import {
  getGuide, setGuide, getSteps, setSteps, getImages, getThumb, getThumbs,
  getImage, setImage, setThumb, deleteStep, captureBytes,
  listSessions, currentSession, switchSession, createSession, deleteSession,
} from '../lib/store.js';
import { parseScribe } from '../lib/scribe.js';
import { restamp, maskSpot, prepareImage } from '../lib/annotate.js';
import {
  buildHtml, buildMarkdownZip, slugify, formatDate, download,
} from '../lib/export.js';
import {
  STEP_KINDS, SECTION_KINDS, isStep, countSteps, numberItems, NUMBER_STYLES,
  numberStyle, startAtOf, stampedLabel,
  FLAGS, FLAG_ORDER, flagOf, calloutFlag, WIDTH_CHOICES, DEFAULT_WIDTH,
  guideWidth, widthOf, HEADING_LEVELS, headingLevel, tocEntries, newSection,
} from '../lib/doc.js';

const webext = globalThis.browser?.runtime?.getBrowserInfo ? globalThis.browser : globalThis.chrome;
const $ = (id) => document.getElementById(id);

const KINDS = STEP_KINDS;
const TYPED = new Set(['type', 'select']);
const UNDO_MAX = 30;
// Both a step's note and a section's prose live in `note`, so one selector list
// per key is enough for the undo machinery to find the field again.
const FIELDS = {
  title: '.step-title, .block-title',
  note: '.step-note, .block-text, .block-cap',
  text: '.step-text',
};
const GUIDE_FIELDS = { title: 'title', intro: 'intro', conclusion: 'outro' };

let guide = { title: '', createdAt: null };
let steps = []; // steps and sections, in the order they read
let imgById = new Map();
let thumbs = new Map();
let confirmAction = null;
let savedTimer = null;
let toastTimer = null;
let toastEntry = null;
let observer = null;
let undoStack = [];
let current = 0;
let navLock = 0;
let drag = null;
let clickGuard = 0;
let chain = Promise.resolve();
let sessionId = null;
let importing = null; // { stop } while an import is fetching screenshots

const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

init();

async function init() {
  fillPickers();
  await load();
  render();

  bindGuideField('title', $('title'), 'Guide title', () => focusField(0, 'title'));
  bindGuideField('intro', $('intro'), 'Intro', () => focusField(0, 'title'));
  bindGuideField('conclusion', $('outro'), 'Conclusion', () => $('outro').blur());

  for (const [id, key] of [['optToc', 'toc'], ['optIntro', 'showIntro'], ['optOutro', 'showOutro']]) {
    $(id).addEventListener('change', async (e) => {
      guide[key] = e.target.checked;
      await setGuide({ [key]: e.target.checked });
      render();
      // A section you just switched on is no use if you have to go looking
      // for it, so the caret lands in it.
      if (e.target.checked && key === 'showIntro') $('intro').focus();
      if (e.target.checked && key === 'showOutro') $('outro').focus();
      flashSaved();
    });
  }

  $('optWidth').addEventListener('change', async (e) => {
    guide.imgWidth = Number(e.target.value) || DEFAULT_WIDTH;
    await setGuide({ imgWidth: guide.imgWidth });
    render();
    flashSaved();
  });

  // Changing how steps are written changes what is stamped into every
  // screenshot, so this goes through the same re-stamping path as a reorder.
  $('optNumbering').addEventListener('change', async (e) => {
    guide.numbering = e.target.value === 'section' ? 'section' : 'plain';
    await setGuide({ numbering: guide.numbering });
    render();
    await commitOrder();
  });

  bindAddMenu();
  bindLibrary();

  $('exportHtml').addEventListener('click', exportHtml);
  $('exportMd').addEventListener('click', exportMarkdown);
  // Pushing happens in the card drawn on an Author Workbench page; this opens
  // (or finds) that page and the card on it.
  $('sendAwb').addEventListener('click', () => {
    webext.runtime.sendMessage({ type: 'ms:openWorkbench' }).catch(() => {});
  });
  $('undoBtn').addEventListener('click', () => undo());
  $('toastUndo').addEventListener('click', () => {
    const entry = toastEntry;
    hideToast();
    if (!entry) return;
    const i = undoStack.indexOf(entry);
    // The stack is emptied when the capture is deleted or discarded. Acting on
    // an entry that is no longer in it would put a screenshot back into a
    // capture the user just threw away.
    if (i < 0) return;
    undoStack.splice(i, 1);
    runUndo(entry);
  });

  $('clear').addEventListener('click', () => ask(
    deleteAllText(),
    'Delete',
    async () => {
      await reopen(await deleteSession(sessionId));
    },
  ));

  $('sheetCancel').addEventListener('click', closeSheet);
  $('sheetOk').addEventListener('click', async () => {
    const act = confirmAction;
    closeSheet();
    if (act) await act();
  });

  document.addEventListener('keydown', onKeydown);
  window.addEventListener('resize', debounce(() => sizeAll(), 120));

  // Reordering is driven from the rail with the pointer; the arrow buttons on
  // each step stay the keyboard-and-test path.
  $('rail').addEventListener('pointerdown', onRailPointerDown);

  // Which capture is current is a fact about storage rather than about any one
  // page, so it is watched there: switching in another tab, or starting a new
  // capture from the popup, has to land here or this page would keep showing
  // the old one and write it back over the new one on the next edit.
  webext.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes['ms:current']) return;
    if (changes['ms:current'].newValue === sessionId) return;
    reopen();
  });

  webext.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    // A discard elsewhere has to land here too — otherwise this page would
    // keep showing deleted steps and write them back on the next edit.
    if (msg.type === 'ms:cleared') {
      undoStack = [];
      hideToast();
      syncUndoButton();
      load().then(render);
      return;
    }
    if (msg.type !== 'ms:stepAdded') return;
    // Re-render even while a field has focus: render() restores focus, caret
    // and unsaved text. Skipping it used to leave this page holding a stale
    // array that the next edit would write back, erasing the step that just
    // arrived and stranding its screenshot.
    load().then(render);
  });
}

async function load() {
  [guide, steps, sessionId] = await Promise.all([getGuide(), getSteps(), currentSession()]);
  const ids = steps.map((s) => s.id);
  const [list, thumbList] = await Promise.all([getImages(ids), getThumbs(ids)]);
  // An imported step whose screenshot was left where it lives on the web has
  // no bytes here, only an address — and every surface downstream puts what
  // this map holds into an img src or an ![](…), so the address does the job.
  imgById = new Map(ids.map((id, i) => [id, list[i] || steps[i].src || null]));
  // Not the remote address though: the rail draws every row at once, and two
  // hundred full-size screenshots fetched to be shown at 44px is not a
  // thumbnail. A row simply goes without a picture until one is downloaded.
  thumbs = new Map(ids.map((id, i) => [id, thumbList[i]]));
}

const kindOf = (step) => (KINDS[step.kind] ? step.kind : 'click');
const imagesInOrder = () => steps.map((s) => imgById.get(s.id) || null);
const numbered = () => numberItems(steps, guide);

// "07" reads as a step number; "1.7" reads as itself and padding would only
// make it look like a decimal.
const showLabel = (label) => (label && label.length === 1 ? `0${label}` : label || '');

// The pickers are built from lib/doc.js rather than written out in the HTML, so
// adding an alert level or a width means touching one list.
function fillPickers() {
  const opt = (value, text) => {
    const o = document.createElement('option');
    o.value = value;
    o.textContent = text;
    return o;
  };

  $('optWidth').replaceChildren(...WIDTH_CHOICES.map((w) => opt(String(w), `${w}% wide`)));
  $('optNumbering').replaceChildren(
    ...Object.entries(NUMBER_STYLES).map(([key, text]) => opt(key, text)),
  );

  const flags = [opt('', 'No mark'), ...FLAG_ORDER.map((k) => opt(k, `${FLAGS[k].emoji} ${FLAGS[k].label}`))];
  const widths = [opt('', 'Default width'), ...WIDTH_CHOICES.map((w) => opt(String(w), `${w}%`))];
  const levels = HEADING_LEVELS.map((l) => opt(String(l), `Level ${l}`));

  const stock = (sel, list) => sel && sel.replaceChildren(...list.map((o) => o.cloneNode(true)));
  const tpl = (id) => $(id).content;
  stock(tpl('stepTpl').querySelector('.flag-pick'), flags);
  stock(tpl('stepTpl').querySelector('.width-pick'), widths);
  stock(tpl('sectionTpl').querySelector('.block-flag'), flags.slice(1));
  stock(tpl('sectionTpl').querySelector('.block-width'), widths);
  stock(tpl('sectionTpl').querySelector('.block-level'), levels);
}

/* ------------------------------- rendering ------------------------------ */

function render() {
  const has = steps.length > 0;
  $('empty').hidden = has;
  $('steps').hidden = !has;
  $('exportHtml').disabled = !has;
  $('exportMd').disabled = !has;
  $('sendAwb').disabled = !has;

  const keep = focusSnapshot();
  // With nothing captured, the rail's affordances have nothing to act on.
  for (const id of ['railLabel', 'keys', 'clear', 'docHead']) {
    const el = $(id);
    if (el) el.hidden = !has;
  }

  $('title').value = guide.title || '';
  renderCaptureName();
  renderDocOptions();
  renderMeta();
  renderRail();
  renderItems();
  current = Math.max(0, Math.min(current, steps.length - 1));
  markCurrent();
  sizeAll();
  restoreFocus(keep);
  watchScroll();
  syncUndoButton();
}

// Intro and conclusion are switched on rather than always present: most
// captures are a flow and nothing else, and an empty box above step one would
// read as something the author forgot to fill in.
function renderDocOptions() {
  $('optToc').checked = !!guide.toc;
  $('optIntro').checked = !!guide.showIntro;
  $('optOutro').checked = !!guide.showOutro;
  $('optWidth').value = String(guideWidth(guide));
  $('optNumbering').value = numberStyle(guide);

  $('introBox').hidden = !guide.showIntro || !steps.length;
  $('outroBox').hidden = !guide.showOutro || !steps.length;
  $('intro').value = guide.intro || '';
  $('outro').value = guide.conclusion || '';

  renderToc();
}

function renderToc() {
  const entries = tocEntries(steps);
  $('tocBox').hidden = !guide.toc || !steps.length;
  $('tocEmpty').hidden = entries.length > 0;
  $('tocList').replaceChildren(...entries.map((entry) => {
    const li = document.createElement('li');
    li.className = `lv${entry.depth + 1}`;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'toc-link';
    btn.textContent = entry.text;
    btn.addEventListener('click', () => {
      const at = steps.findIndex((s) => s.id === entry.id);
      if (at >= 0) setCurrent(at, { scroll: true });
    });
    li.append(btn);
    return li;
  }));
}

async function renderMeta() {
  if (!steps.length) {
    $('meta').textContent = 'Nothing recorded';
    return;
  }
  const count = countSteps(steps);
  const sections = steps.length - count;
  const first = steps.find(isStep);
  const date = formatDate(guide.createdAt || (first && first.ts));
  const bytes = await captureBytes(steps);
  const parts = [`${count} step${count === 1 ? '' : 's'}`];
  if (sections) parts.push(`${sections} section${sections === 1 ? '' : 's'}`);
  if (date) parts.push(`captured ${date}`);
  const mb = bytes / 1048576;
  if (mb >= 0.05) parts.push(`${mb.toFixed(1)} MB`);
  $('meta').textContent = parts.join(' · ');
}

function renderRail() {
  const rail = $('rail');
  const tpl = $('railTpl');
  rail.textContent = '';

  numbered().forEach(({ item, label }, i) => {
    const li = tpl.content.firstElementChild.cloneNode(true);
    li.dataset.id = item.id;
    li.dataset.flip = `r:${item.id}`;

    const btn = li.querySelector('.rail-item');
    btn.dataset.target = `step-${item.id}`;

    const text = railLabelFor(item);
    btn.title = text;
    li.querySelector('.t').textContent = text;

    const thumb = thumbs.get(item.id);
    const img = li.querySelector('img');
    if (thumb) img.src = thumb;
    else img.remove();

    const chip = li.querySelector('.chip');

    if (isStep(item)) {
      li.querySelector('.n').textContent = showLabel(label);
      const kind = kindOf(item);
      const flag = flagOf(item);
      if (flag) {
        chip.hidden = false;
        chip.dataset.kind = 'flag';
        chip.textContent = FLAGS[flag].emoji;
        chip.title = FLAGS[flag].label;
      } else if (kind === 'click') {
        chip.remove();
      } else {
        chip.hidden = false;
        chip.dataset.kind = kind;
        chip.textContent = kind === 'type' ? 'T' : 'S';
        chip.title = KINDS[kind];
      }
    } else {
      // Sections aren't numbered, so the number cell carries the kind instead
      // and the row is dimmer — the rail should still read as a list of steps.
      li.classList.add('is-section');
      li.querySelector('.n').textContent =
        item.kind === 'heading' ? `H${headingLevel(item)}` : '··';
      chip.hidden = false;
      chip.dataset.kind = 'section';
      chip.textContent = item.kind === 'callout'
        ? FLAGS[calloutFlag(item)].emoji
        : { heading: '¶', text: 'T', image: '▣' }[item.kind] || '·';
      chip.title = SECTION_KINDS[item.kind] || 'Section';
    }

    btn.addEventListener('click', () => {
      if (Date.now() < clickGuard) return; // the pointer just finished a drag
      setCurrent(i, { scroll: true });
    });

    rail.append(li);
  });
}

function railLabelFor(item) {
  if (isStep(item) || item.kind === 'heading' || item.kind === 'callout') {
    return item.title || (item.kind === 'callout' ? FLAGS[calloutFlag(item)].label : '');
  }
  if (item.kind === 'image') return item.note || 'Image';
  const first = (item.note || '').trim().split('\n')[0];
  return first || 'Text';
}

function renderItems() {
  const list = $('steps');
  list.textContent = '';

  numbered().forEach(({ item, n, label, starts }, i) => {
    list.append(insertRow(i));
    list.append(isStep(item) ? stepNode(item, n, label, i) : sectionNode(item, i, starts));
  });

  if (steps.length) list.append(insertRow(steps.length));
}

// A hairline with a + on it, between every pair of items and at both ends. It
// is how "before, after and in between" is offered: the position is the thing
// being chosen, so it has to be the thing you click.
function insertRow(at) {
  const li = $('insertTpl').content.firstElementChild.cloneNode(true);
  const btn = li.querySelector('.ins-btn');
  btn.setAttribute('aria-label',
    at === 0 ? 'Add a section at the top' : `Add a section after item ${at}`);
  btn.addEventListener('click', () => openAddMenu(btn, at));
  return li;
}

function stepNode(step, n, label, i) {
  const node = $('stepTpl').content.firstElementChild.cloneNode(true);
  const kind = kindOf(step);
  node.id = `step-${step.id}`;
  node.dataset.flip = `s:${step.id}`;
  node.dataset.kind = kind;
  const num = node.querySelector('.num');
  num.textContent = showLabel(label);
  num.classList.toggle('long', num.textContent.length > 2);

  const chip = node.querySelector('.kind');
  chip.dataset.kind = kind;
  chip.textContent = KINDS[kind];

  const title = node.querySelector('.step-title');
  title.value = step.title || '';
  title.dataset.fkey = `${step.id}:title`;
  title.setAttribute('aria-label', `Step ${label} title`);
  bindEditable(title, {
    label: 'Title edit',
    snapshot: () => fieldSnapshot(step.id, { title: currentValue(step.id, 'title') }, 'title'),
    save: (v) => commitStepField(step.id, { title: v }),
    next: () => focusField(indexOf(step.id) + 1, 'title'),
  });

  const typed = node.querySelector('.typed');
  const text = node.querySelector('.step-text');
  if (TYPED.has(kind)) {
    typed.hidden = false;
    typed.querySelector('.typed-label').textContent = kind === 'select' ? 'Selected' : 'Typed';
    text.value = step.text || '';
    // A password is deliberately never stored — say so instead of inviting
    // the user to type one in here.
    text.placeholder = 'not recorded';
    text.dataset.fkey = `${step.id}:text`;
    text.setAttribute('aria-label',
      `Step ${label} ${kind === 'select' ? 'selected' : 'typed'} value`);
    node.querySelector('.submitted').hidden = !step.submitted;
    bindEditable(text, {
      label: 'Typed value edit',
      snapshot: () => fieldSnapshot(
        step.id,
        { text: currentValue(step.id, 'text'), title: currentValue(step.id, 'title') },
        'text',
      ),
      save: (v) => commitTypedValue(step.id, v),
      next: () => focusField(indexOf(step.id), 'note'),
    });
    const redact = node.querySelector('.redact');
    if (!step.text) {
      redact.remove(); // nothing captured, nothing to hide
    } else {
      redact.setAttribute('aria-label', `Redact the value in step ${label}`);
      redact.addEventListener('click', () => askRedact(step));
    }
  } else {
    typed.remove();
  }

  // The mark: an emoji and a colour, both carried into the exports. Colours
  // come from lib/doc.js through a custom property so there is one palette
  // rather than one here and another in the CSS.
  const flag = flagOf(step);
  const flagPick = node.querySelector('.flag-pick');
  flagPick.value = flag || '';
  flagPick.setAttribute('aria-label', `Mark step ${label}`);
  if (flag) {
    node.dataset.flag = flag;
    node.style.setProperty('--flag', FLAGS[flag].color);
  }
  flagPick.addEventListener('change', () => setFlag(step.id, flagPick.value));

  // Renumbering from a step: the count carries on from whatever is typed here,
  // so setting 10 on step three gives 10, 11, 12. Empty means "keep counting".
  const startAt = node.querySelector('.start-at');
  const own = startAtOf(step);
  startAt.value = own == null ? '' : String(own);
  startAt.placeholder = String(n);
  startAt.setAttribute('aria-label', `Number step ${label} from`);
  if (own != null) node.classList.add('has-start');
  startAt.addEventListener('change', () => setStartAt(step.id, startAt.value));

  const note = node.querySelector('.step-note');
  note.value = step.note || '';
  note.dataset.fkey = `${step.id}:note`;
  note.setAttribute('aria-label', `Note for step ${label}`);
  if (flag) note.placeholder = '+ Say what to watch out for';
  bindEditable(note, {
    label: 'Note edit',
    multiline: true,
    snapshot: () => fieldSnapshot(step.id, { note: currentValue(step.id, 'note') }, 'note'),
    save: (v) => commitStepField(step.id, { note: v }),
    next: () => focusField(indexOf(step.id) + 1, 'title'),
  });
  note.addEventListener('focus', () => autosize(note));
  note.addEventListener('blur', () => autosize(note));

  const img = node.querySelector('img');
  const src = imgById.get(step.id);
  const width = widthOf(step, guide);
  if (src) {
    img.src = src;
    img.alt = step.title || '';
    img.style.maxWidth = `${width}%`;
  } else {
    img.remove();
  }

  node.querySelector('.host').textContent = hostOf(step.url);
  node.querySelector('.path').textContent = step.url || '';

  const widthPick = node.querySelector('.width-pick');
  if (src) {
    if (step.imgWidth) node.classList.add('has-width'); // a set width stays on show
    widthPick.value = step.imgWidth ? String(widthOf(step, guide)) : '';
    widthPick.setAttribute('aria-label', `Width of the screenshot in step ${label}`);
    widthPick.addEventListener('change', () => setWidth(step.id, widthPick.value));
  } else {
    widthPick.remove();
  }

  wireTools(node, step.id, i, `step ${label}`);
  return node;
}

function sectionNode(item, i, starts) {
  const node = $('sectionTpl').content.firstElementChild.cloneNode(true);
  node.id = `step-${item.id}`;
  node.dataset.flip = `s:${item.id}`;
  node.dataset.kind = item.kind;
  node.querySelector('.block-kind').textContent = SECTION_KINDS[item.kind] || 'Section';

  const titleBox = node.querySelector('.block-title');
  const textBox = node.querySelector('.block-text');
  const figure = node.querySelector('.block-figure');
  const level = node.querySelector('.block-level');
  const flagPick = node.querySelector('.block-flag');
  const widthPick = node.querySelector('.block-width');

  // A heading has nowhere to go from its own title but on to the next item; a
  // callout has a body underneath, so Enter should land there.
  const bindTitle = (el, placeholder, onward) => {
    el.hidden = false;
    el.value = item.title || '';
    el.placeholder = placeholder;
    el.dataset.fkey = `${item.id}:title`;
    bindEditable(el, {
      label: 'Section edit',
      snapshot: () => fieldSnapshot(item.id, { title: currentValue(item.id, 'title') }, 'title'),
      save: (v) => commitStepField(item.id, { title: v }),
      next: onward,
    });
  };

  const bindProse = (el, placeholder) => {
    el.hidden = false;
    el.value = item.note || '';
    el.placeholder = placeholder;
    el.dataset.fkey = `${item.id}:note`;
    bindEditable(el, {
      label: 'Section edit',
      multiline: true,
      snapshot: () => fieldSnapshot(item.id, { note: currentValue(item.id, 'note') }, 'note'),
      save: (v) => commitStepField(item.id, { note: v }),
      next: () => focusField(indexOf(item.id) + 1, 'title'),
    });
  };

  if (item.kind === 'heading') {
    node.classList.add(`lv${headingLevel(item)}`);
    bindTitle(titleBox, 'Heading', () => focusField(indexOf(item.id) + 1, 'title'));
    level.hidden = false;
    level.value = String(headingLevel(item));
    level.addEventListener('change', () => setLevel(item.id, level.value));
    wireRestart(node, item, starts);
    textBox.remove();
    figure.remove();
  } else if (item.kind === 'callout') {
    const flag = calloutFlag(item);
    node.dataset.flag = flag;
    node.style.setProperty('--flag', FLAGS[flag].color);
    flagPick.hidden = false;
    flagPick.value = flag;
    flagPick.addEventListener('change', () => setFlag(item.id, flagPick.value || 'info'));
    bindTitle(titleBox, FLAGS[flag].label, () => textBox.focus());
    bindProse(textBox, 'What the reader needs to know.');
    figure.remove();
  } else if (item.kind === 'image') {
    titleBox.remove();
    textBox.remove();
    figure.hidden = false;
    wireImageSection(node, item);
    widthPick.hidden = false;
    widthPick.value = item.imgWidth ? String(widthOf(item, guide)) : '';
    widthPick.addEventListener('change', () => setWidth(item.id, widthPick.value));
  } else {
    titleBox.remove();
    bindProse(textBox, 'Anything the screenshots can’t say. **bold**, *italic*, `code`, [links](https://example.com) and - bullets all carry into the exports.');
    figure.remove();
  }

  wireTools(node, item.id, i, SECTION_KINDS[item.kind] || 'section');
  return node;
}

// The reason numbering is restartable at all: a heading is where an author
// starts a new sequence of steps, the way a numbered document does it — so a
// top-level heading arrives with this already on, and the box is as much a way
// to say "no, keep counting" as a way to say where to count from. In 1.1 mode
// the same switch is what makes this heading section 2 rather than still
// section 1.
//
// `starts` is what the document rules make of this heading, not what is stored
// on it, so the box shows the number the section will actually begin at.
function wireRestart(node, item, starts) {
  const box = node.querySelector('.block-restart');
  const on = node.querySelector('.restart-on');
  const at = node.querySelector('.restart-at');

  box.hidden = false;
  on.checked = starts != null;
  at.hidden = starts == null;
  at.value = String(starts == null ? 1 : starts);
  at.setAttribute('aria-label', 'Restart numbering at');
  if (starts != null) node.classList.add('has-start');

  on.addEventListener('change', () => setRestart(item.id, on.checked, at.value));
  at.addEventListener('change', () => setRestart(item.id, true, at.value));
}

// An image section holds its picture in exactly the same place a step holds its
// screenshot — ms:img:<id> — so discarding a capture takes it along and the
// exports need no second code path to find it.
function wireImageSection(node, item) {
  const img = node.querySelector('img');
  const drop = node.querySelector('.drop');
  const file = node.querySelector('.block-file');
  const cap = node.querySelector('.block-cap');
  const src = imgById.get(item.id);

  if (src) {
    img.hidden = false;
    img.src = src;
    img.alt = item.note || '';
    img.style.maxWidth = `${widthOf(item, guide)}%`;
    drop.querySelector('p').textContent = 'Drop or paste another to replace it, or';
  }

  node.querySelector('[data-act="pick"]').addEventListener('click', () => file.click());
  file.addEventListener('change', () => {
    const picked = file.files && file.files[0];
    if (picked) readImage(item.id, picked);
    file.value = '';
  });

  // Paste and drag-and-drop, because that is how a screenshot actually arrives:
  // from the clipboard or from a file manager, not through a file dialog.
  node.addEventListener('paste', (e) => {
    const found = [...(e.clipboardData ? e.clipboardData.files : [])].find((f) => f.type.startsWith('image/'));
    if (!found) return;
    e.preventDefault();
    readImage(item.id, found);
  });
  for (const type of ['dragover', 'dragenter']) {
    node.addEventListener(type, (e) => {
      e.preventDefault();
      node.classList.add('dropping');
    });
  }
  node.addEventListener('dragleave', () => node.classList.remove('dropping'));
  node.addEventListener('drop', (e) => {
    e.preventDefault();
    node.classList.remove('dropping');
    const found = [...(e.dataTransfer ? e.dataTransfer.files : [])].find((f) => f.type.startsWith('image/'));
    if (found) readImage(item.id, found);
  });

  cap.value = item.note || '';
  cap.dataset.fkey = `${item.id}:note`;
  bindEditable(cap, {
    label: 'Caption edit',
    snapshot: () => fieldSnapshot(item.id, { note: currentValue(item.id, 'note') }, 'note'),
    save: (v) => commitStepField(item.id, { note: v }),
    next: () => focusField(indexOf(item.id) + 1, 'title'),
  });
}

function wireTools(node, id, i, what) {
  const tools = node.querySelectorAll('.tool');
  tools[0].disabled = i === 0;
  tools[1].disabled = i === steps.length - 1;
  tools[0].setAttribute('aria-label', `Move ${what} up`);
  tools[1].setAttribute('aria-label', `Move ${what} down`);
  tools[2].setAttribute('aria-label', `Delete ${what}`);
  tools[0].addEventListener('click', () => move(indexOf(id), -1));
  tools[1].addEventListener('click', () => move(indexOf(id), 1));
  tools[2].addEventListener('click', () => remove(id));

  node.addEventListener('focusin', () => {
    const at = indexOf(id);
    if (at >= 0) setCurrent(at);
  });
}

/* ------------------------------- the library ---------------------------- */
//
// Captures are a list, and only one of them is loaded at a time — see
// lib/store.js for why that is the shape. This page is where the list is kept,
// because the editor is where a capture is a document rather than a recording
// in progress.

function bindLibrary() {
  const menu = $('library');

  $('captureBtn').addEventListener('click', () => {
    if (menu.hidden) openLibrary();
    else closeLibrary();
  });

  $('newCapture').addEventListener('click', async () => {
    closeLibrary();
    await reopen(await createSession());
  });

  $('importScribe').addEventListener('click', () => {
    closeLibrary();
    openImport();
  });

  document.addEventListener('pointerdown', (e) => {
    if (menu.hidden) return;
    if (!menu.contains(e.target) && !e.target.closest('#captureBtn')) closeLibrary();
  });
  window.addEventListener('resize', closeLibrary);

  bindImport();
}

// One line has to hold the count, where it came from and when, so the month is
// abbreviated here where the document's own meta line spells it out.
const shortDate = (ts) =>
  new Date(ts).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

// The title as the switcher says it, which is the guide's own title — an
// untitled capture says so rather than showing an empty button.
function renderCaptureName() {
  const count = countSteps(steps);
  $('captureName').textContent = guide.title || 'Untitled capture';
  $('captureMeta').textContent = count ? `${count} step${count === 1 ? '' : 's'}` : 'empty';
}

async function openLibrary() {
  const menu = $('library');
  menu.hidden = false;
  $('captureBtn').setAttribute('aria-expanded', 'true');
  const box = $('captureBtn').getBoundingClientRect();
  menu.style.left = `${Math.max(12, Math.min(box.left, window.innerWidth - menu.offsetWidth - 12))}px`;
  menu.style.top = `${box.bottom + 8}px`;
  await renderLibrary();
  const first = menu.querySelector('.library-item');
  if (first) first.focus();
}

function closeLibrary() {
  $('library').hidden = true;
  $('captureBtn').setAttribute('aria-expanded', 'false');
}

async function renderLibrary() {
  const list = await listSessions();
  $('libraryCount').textContent = `${list.length}`;

  const tpl = $('libraryTpl');
  $('libraryList').replaceChildren(...list.map((entry) => {
    const li = tpl.content.firstElementChild.cloneNode(true);
    li.classList.toggle('current', entry.current);

    li.querySelector('.library-title').textContent = entry.title;
    const bits = [`${entry.steps} step${entry.steps === 1 ? '' : 's'}`];
    if (entry.sections) bits.push(`${entry.sections} section${entry.sections === 1 ? '' : 's'}`);
    if (entry.origin === 'scribe') bits.push('imported');
    if (entry.createdAt) bits.push(shortDate(entry.createdAt));
    li.querySelector('.library-sub').textContent = bits.join(' · ');

    const open = li.querySelector('.library-item');
    open.title = entry.title || 'Untitled capture';
    open.addEventListener('click', async () => {
      closeLibrary();
      if (entry.current) return;
      await switchSession(entry.id);
      await reopen(entry.id);
    });

    li.querySelector('.library-del').addEventListener('click', () => {
      closeLibrary();
      const holds = entry.steps
        ? `Its ${bits[0]} and every screenshot go with it.`
        : 'There is nothing in it.';
      ask(
        `Delete "${entry.title || 'Untitled capture'}"? ${holds}`,
        'Delete',
        async () => {
          await reopen(await deleteSession(entry.id));
        },
      );
    });

    return li;
  }));
}

// Everything that changes which capture is loaded ends here: the in-flight
// undo history belongs to the capture that has just gone, and keeping it would
// let Undo put a step back into a document it was never in.
//
// `landed` is the capture this page is on its way to. Claiming it up front is
// what stops the storage watcher, which is about to see the very write this
// page just made, from reading the whole document a second time.
async function reopen(landed) {
  if (landed) sessionId = landed;
  undoStack = [];
  hideToast();
  syncUndoButton();
  current = 0;
  await load();
  render();
  window.scrollTo({ top: 0, behavior: 'auto' });
  webext.runtime.sendMessage({ type: 'ms:refreshBadge' }).catch(() => {});
}

/* -------------------------- importing an old lab ------------------------ */

function bindImport() {
  const text = $('importText');
  const go = $('importGo');

  const gauge = () => {
    go.disabled = !!importing || !text.value.trim();
  };
  text.addEventListener('input', gauge);

  $('importPick').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    text.value = await file.text();
    // The filename is the best title going when the markdown has no h1.
    text.dataset.name = file.name.replace(/\.[^.]+$/, '');
    say(`read ${file.name}`);
    gauge();
  });

  $('importCancel').addEventListener('click', () => {
    if (importing) {
      importing.stop = true;
      return;
    }
    closeImport();
  });

  go.addEventListener('click', runImport);
}

function openImport() {
  $('importSheet').hidden = false;
  say('');
  $('importGo').disabled = !$('importText').value.trim();
  $('importText').focus();
}

function closeImport() {
  if (importing) return;
  $('importSheet').hidden = true;
  $('importText').value = '';
  delete $('importText').dataset.name;
  say('');
}

function say(text, bad) {
  const el = $('importState');
  el.textContent = text || '';
  el.className = `import-state${bad ? ' bad' : ''}`;
}

async function runImport() {
  const source = $('importText').value;
  if (!source.trim() || importing) return;

  let parsed;
  try {
    parsed = parseScribe(source, { title: $('importText').dataset.name });
  } catch (err) {
    say(`could not read that: ${(err && err.message) || err}`, true);
    return;
  }
  if (!parsed.items.length) {
    say('nothing in there looked like a lab', true);
    return;
  }

  // The capture exists before a single picture is fetched, so what arrived is
  // on screen behind this sheet while the screenshots come down — and a
  // download that fails or is stopped leaves a whole lab rather than nothing.
  await reopen(await createSession({ guide: parsed.guide, steps: parsed.items }));

  const pictures = parsed.pictures;
  if (!pictures.length || !$('importGrab').checked) {
    say('');
    closeImport();
    toast(`Imported ${parsed.count} step${parsed.count === 1 ? '' : 's'}`);
    return;
  }

  importing = { stop: false };
  $('importGo').disabled = true;
  $('importCancel').textContent = 'Stop';
  const remote = await grabPictures(pictures, (done, total, bad) =>
    say(`downloading screenshots — ${done} of ${total}${bad ? `, ${bad} failed` : ''}`));
  importing = null;
  $('importCancel').textContent = 'Cancel';

  await reopen();
  closeImport();
  const steps = `${parsed.count} step${parsed.count === 1 ? '' : 's'}`;
  toast(
    remote
      ? `Imported ${steps} · ${remote} screenshot${remote === 1 ? '' : 's'} left where they are`
      : `Imported ${steps}`,
  );
}

// Brings the screenshots onto this machine, which is what makes an imported
// lab behave like a recorded one: exportable offline, re-uploadable to a lab
// of its own, and gone for good when the capture is deleted. One that cannot
// be fetched keeps its address and is still shown and still exported — it just
// stays somebody else's file.
async function grabPictures(pictures, onProgress) {
  const queue = [...pictures];
  const sized = new Map();
  let done = 0;
  let failed = 0;

  const worker = async () => {
    for (;;) {
      const next = queue.shift();
      if (!next || importing.stop) return;
      try {
        const res = await fetch(next.url, { credentials: 'omit', redirect: 'follow' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const blob = await res.blob();
        if (blob.size === 0) throw new Error('empty');
        // Same treatment a screenshot gets: capped, re-encoded, thumbnailed.
        const out = await prepareImage(await asDataUrl(blob));
        await setImage(next.id, out.image);
        await setThumb(next.id, out.thumb);
        sized.set(next.id, out);
      } catch (err) {
        failed += 1;
        console.warn(`[Bartleby] could not fetch ${next.url}:`, err && err.message);
      }
      onProgress(++done, pictures.length, failed);
    }
  };

  await Promise.all(Array.from({ length: Math.min(5, queue.length) }, worker));

  // The real pixel dimensions, which is what a narrowed image needs to be
  // written as a width in the Skills Network export.
  if (sized.size) {
    const items = await getSteps();
    for (const item of items) {
      const out = sized.get(item.id);
      if (!out) continue;
      item.width = out.width;
      item.height = out.height;
    }
    await setSteps(items);
  }
  // How many are still somebody else's file — which is the ones that failed
  // plus, if it was stopped, the ones never reached.
  return pictures.length - sized.size;
}

const asDataUrl = (blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('could not read the image'));
    reader.readAsDataURL(blob);
  });

/* ---------------------------- adding sections --------------------------- */

let addAt = null;

function bindAddMenu() {
  const menu = $('addMenu');
  menu.querySelectorAll('[data-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const at = addAt;
      closeAddMenu();
      if (at != null) addSection(btn.dataset.add, at);
    });
  });
  document.addEventListener('pointerdown', (e) => {
    if (menu.hidden) return;
    if (!menu.contains(e.target) && !e.target.closest('.ins-btn')) closeAddMenu();
  });
  window.addEventListener('resize', closeAddMenu);
  window.addEventListener('scroll', closeAddMenu, { passive: true });
}

function openAddMenu(anchor, at) {
  const menu = $('addMenu');
  if (!menu.hidden && addAt === at) {
    closeAddMenu();
    return;
  }
  addAt = at;
  menu.hidden = false;
  const box = anchor.getBoundingClientRect();
  const width = menu.offsetWidth;
  const left = Math.max(12, Math.min(box.left, window.innerWidth - width - 12));
  const below = box.bottom + 8;
  const room = window.innerHeight - below > menu.offsetHeight + 12;
  menu.style.left = `${left}px`;
  menu.style.top = `${room ? below : Math.max(12, box.top - menu.offsetHeight - 8)}px`;
  menu.querySelector('.addmenu-item').focus();
}

function closeAddMenu() {
  addAt = null;
  $('addMenu').hidden = true;
}

async function addSection(kind, at) {
  const item = newSection(kind);
  const first = captureRects();
  steps.splice(Math.min(at, steps.length), 0, item);
  current = Math.min(at, steps.length - 1);
  render();
  playFlip(first);

  const entry = pushUndo({ label: 'Add section', run: () => undoAdd(item.id) });
  toast(`${SECTION_KINDS[kind]} added`, entry);

  // A heading is a new section, and a section starts its own count — so unlike
  // the other section kinds this one renumbers the steps below it, and their
  // numbers are stamped into the screenshots. Re-stamping re-renders, so it
  // has to happen before the cursor is put in the field.
  if (kind === 'heading') {
    await commitOrder();
  } else {
    await persistSteps(steps);
    flashSaved();
  }

  // Straight into the field the author is going to type in — except for an
  // image, where the next move is choosing a file.
  const key = kind === 'heading' || kind === 'callout' ? 'title' : 'note';
  focusField(indexOf(item.id), key);
  if (kind === 'image') {
    const node = document.getElementById(`step-${item.id}`);
    if (node) node.querySelector('[data-act="pick"]').focus();
  } else if (item.title) {
    // A new heading arrives with a placeholder word in it; select it so the
    // first thing typed replaces it rather than running on from it.
    const el = document.querySelector(`[data-fkey="${item.id}:title"]`);
    if (el) el.select();
  }
}

async function undoAdd(id) {
  const at = indexOf(id);
  if (at < 0) return;
  const heading = steps[at].kind === 'heading';
  const first = captureRects();
  steps.splice(at, 1);
  imgById.delete(id);
  thumbs.delete(id);
  current = Math.max(0, Math.min(at, steps.length - 1));
  render();
  playFlip(first);
  await deleteStep(id);
  // Taking a heading back out closes the section it opened, so the steps below
  // it go back to counting from wherever the previous one left off.
  if (heading) {
    await commitOrder([id]);
    flashSaved('Undone');
    return;
  }
  await persistSteps(steps, [id]);
  flashSaved('Undone');
}

/* ------------------------- marks, widths, images ------------------------ */

// Every change to an item goes through here, and it queues behind whatever
// re-stamping is in flight. commitOrder ends by reading storage back into
// `steps`, so an edit applied to the array it is about to replace would be
// silently discarded — which is exactly what happens if you tick "restart
// numbering" and then type the number while the images are still being
// re-stamped.
function editItem(id, change) {
  return serialize(async () => {
    const item = steps.find((x) => x.id === id);
    if (!item || change(item) === false) return false;
    await persistSteps(steps);
    return true;
  });
}

async function setFlag(id, flag) {
  const changed = await editItem(id, (item) => {
    const next = FLAGS[flag] ? flag : '';
    if (next === (item.flag || '')) return false;
    item.flag = next;
    return true;
  });
  if (!changed) return;
  render();
  flashSaved();
}

// Every step after this one is renumbered, and those numbers are baked into
// the screenshots — so this goes through commitOrder, which re-stamps only the
// images whose number actually changed.
async function setStartAt(id, value) {
  const next = startAtOf({ startAt: value });
  const changed = await editItem(id, (item) => {
    if (next === startAtOf(item)) return false;
    item.startAt = next;
    return true;
  });
  if (!changed) return;
  render();
  await commitOrder();
}

// A heading's level is what decides whether it is the document's top tier, and
// the top tier is what restarts the count — so demoting one can renumber every
// step under every heading in the document, and those numbers are baked into
// the screenshots. Hence commitOrder rather than a redraw.
async function setLevel(id, value) {
  const next = headingLevel({ level: Number(value) });
  const changed = await editItem(id, (item) => {
    if (next === headingLevel(item)) return false;
    item.level = next;
    return true;
  });
  if (!changed) return;
  render();
  await commitOrder();
}

// Both halves of the answer are written down, because the default depends on
// the heading's level and the author's decision should not: ticking pins the
// number even when it is the 1 a top-level heading would have used anyway, and
// unticking has to be recorded too or the default would just restart it again.
async function setRestart(id, on, value) {
  const from = on ? startAtOf({ startAt: value }) || 1 : null;
  const changed = await editItem(id, (item) => {
    if (from === startAtOf(item) && !on === !!item.continues) return false;
    item.startAt = from;
    item.continues = !on;
    return true;
  });
  if (!changed) return;
  render();
  await commitOrder();
}

async function setWidth(id, value) {
  const changed = await editItem(id, (item) => {
    const next = value ? Number(value) : null;
    if (next === (item.imgWidth ?? null)) return false;
    item.imgWidth = next;
    return true;
  });
  if (!changed) return;
  render();
  flashSaved();
}

async function readImage(id, blob) {
  setSaved('Reading');
  try {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error('could not read the file'));
      reader.readAsDataURL(blob);
    });
    // Same treatment a screenshot gets: capped, re-encoded, thumbnailed.
    const out = await prepareImage(dataUrl);
    await setImage(id, out.image);
    await setThumb(id, out.thumb);
    const item = steps.find((x) => x.id === id);
    if (item) {
      item.width = out.width;
      item.height = out.height;
      await persistSteps(steps);
    }
    imgById.set(id, out.image);
    thumbs.set(id, out.thumb);
    render();
    flashSaved();
  } catch (err) {
    console.warn('[Bartleby] could not read that image:', err && err.message);
    flashSaved('Not an image');
  }
}

function watchScroll() {
  if (observer) observer.disconnect();
  if (!steps.length) return;

  observer = new IntersectionObserver(
    (entries) => {
      if (Date.now() < navLock) return;
      const hit = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (!hit) return;
      const at = steps.findIndex((s) => `step-${s.id}` === hit.target.id);
      if (at >= 0 && at !== current) {
        current = at;
        markCurrent();
      }
    },
    { rootMargin: '-88px 0px -60% 0px', threshold: 0 },
  );
  document.querySelectorAll('.step, .block').forEach((el) => observer.observe(el));
}

/* ------------------------------- selection ------------------------------ */

function markCurrent() {
  const step = steps[current];
  const id = step ? step.id : null;
  document.querySelectorAll('.step, .block').forEach((el) => {
    el.classList.toggle('is-current', !!id && el.id === `step-${id}`);
  });
  document.querySelectorAll('.rail-item').forEach((el) => {
    el.classList.toggle('active', !!id && el.dataset.target === `step-${id}`);
  });
  if (id) keepRailInView(id);
}

function setCurrent(i, { scroll = false } = {}) {
  if (!steps.length) return;
  current = Math.max(0, Math.min(i, steps.length - 1));
  markCurrent();
  if (!scroll) return;
  const el = document.getElementById(`step-${steps[current].id}`);
  if (!el) return;
  navLock = Date.now() + 700;
  el.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'start' });
}

// scrollIntoView would drag the whole page around, so the rail scrolls itself.
function keepRailInView(id) {
  const list = $('rail');
  const row = list.querySelector(`[data-id="${id}"]`);
  if (!row || drag) return;
  const rb = row.getBoundingClientRect();
  const lb = list.getBoundingClientRect();
  if (rb.top < lb.top) list.scrollTop -= lb.top - rb.top + 6;
  else if (rb.bottom > lb.bottom) list.scrollTop += rb.bottom - lb.bottom + 6;
}

function syncRail() {
  steps.forEach((item) => {
    const row = $('rail').querySelector(`[data-id="${item.id}"]`);
    if (!row) return;
    const label = railLabelFor(item);
    row.querySelector('.t').textContent = label;
    row.querySelector('.rail-item').title = label;
  });
}

/* ---------------------------- editable fields --------------------------- */

function currentValue(id, key) {
  const s = steps.find((x) => x.id === id);
  return (s && s[key]) || '';
}

function fieldSnapshot(id, fields, focus) {
  return { id, fields, focus };
}

const indexOf = (id) => steps.findIndex((s) => s.id === id);

// The title, the intro and the conclusion all belong to the guide rather than
// to any one step, and all three want the same editing behaviour: save as you
// type, Escape puts it back, Enter moves on.
function bindGuideField(key, el, label, next) {
  bindEditable(el, {
    label,
    multiline: key !== 'title',
    snapshot: () => ({ guide: key, value: guide[key] || '' }),
    save: async (v) => {
      guide[key] = v;
      await setGuide({ [key]: v });
      flashSaved();
    },
    next,
  });
}

function bindEditable(el, cfg) {
  let base = null;
  let baseValue = el.value;
  const flush = debounce(() => cfg.save(el.value), 350);

  el.addEventListener('focus', () => {
    base = cfg.snapshot();
    baseValue = el.value;
  });

  el.addEventListener('input', () => {
    autosize(el);
    flush();
  });

  el.addEventListener('blur', () => {
    flush.now();
    const snap = base;
    base = null;
    if (snap && el.value !== baseValue) {
      pushUndo({ label: cfg.label, run: () => restoreField(snap) });
    }
  });

  el.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      flush.cancel();
      const snap = base;
      if (!snap) return;
      // Put the old text back right away, then let the write catch up.
      const own = snap.guide ? snap.value : snap.fields[snap.focus];
      el.value = own;
      baseValue = own;
      autosize(el);
      restoreField(snap, { quiet: true });
      flashSaved('Reverted');
      return;
    }
    if (e.key === 'Enter' && !(cfg.multiline && e.shiftKey)) {
      e.preventDefault();
      flush.now();
      cfg.next();
    }
  });
}

// The recorder can append a step while this page is mid-edit, so writing the
// whole in-memory array back would erase it and strand its screenshot. Keep
// anything storage has that we never knew about.
async function persistSteps(next, removedIds) {
  const stored = await getSteps();
  const known = new Set(next.map((x) => x.id));
  const dropped = new Set(removedIds || []);
  const arrivals = stored.filter((x) => !known.has(x.id) && !dropped.has(x.id));
  const merged = arrivals.length ? next.concat(arrivals) : next;
  await setSteps(merged);
  if (arrivals.length) {
    steps = merged;
    await load();
    render();
  }
  return merged;
}

// Rewrites the value inside a title, preferring the quoted occurrence the
// recorder wrote. Replacing every match would turn `Type "1" into the Line 1
// field` into `Type "x" into the Line x field`.
function swapValue(title, from, to) {
  const quoted = `"${from}"`;
  const at = title.indexOf(quoted);
  if (at >= 0) return title.slice(0, at) + `"${to}"` + title.slice(at + quoted.length);
  const i = title.indexOf(from);
  return i < 0 ? title : title.slice(0, i) + to + title.slice(i + from.length);
}

async function commitStepField(id, patch, redraw = false) {
  const changed = await editItem(id, (item) => { Object.assign(item, patch); });
  if (!changed) return;
  if (redraw) {
    render();
  } else if ('title' in patch || 'note' in patch) {
    syncRail();
    renderToc(); // a heading's words are also a line in the contents
  }
  flashSaved();
}

// Editing the typed value rewrites the same string inside the title, so
// redacting a password is one edit rather than two.
async function commitTypedValue(id, next) {
  let title = null;
  const changed = await editItem(id, (item) => {
    const prev = item.text || '';
    if (prev && next !== prev && item.title && item.title.includes(prev)) {
      item.title = swapValue(item.title, prev, next);
      title = item.title;
    }
    item.text = next;
  });
  if (!changed) return;

  if (title != null) {
    const el = document.querySelector(`[data-fkey="${id}:title"]`);
    if (el && document.activeElement !== el) {
      el.value = title;
      autosize(el);
    }
  }
  syncRail();
  flashSaved();
}

async function restoreField(snap, { quiet = false } = {}) {
  if (snap.guide) {
    guide[snap.guide] = snap.value;
    await setGuide({ [snap.guide]: snap.value });
    const el = $(GUIDE_FIELDS[snap.guide]);
    el.value = snap.value;
    autosize(el);
    el.focus();
    if (!quiet) flashSaved('Reverted');
    return;
  }
  const restored = await editItem(snap.id, (item) => { Object.assign(item, snap.fields); });
  if (!restored) return;

  const host = document.getElementById(`step-${snap.id}`);
  if (host) {
    for (const key of Object.keys(snap.fields)) {
      const el = host.querySelector(FIELDS[key]);
      if (!el) continue;
      el.value = snap.fields[key];
      autosize(el);
    }
    const focusEl = host.querySelector(FIELDS[snap.focus]);
    if (focusEl && !quiet) {
      setCurrent(indexOf(snap.id), { scroll: true });
      focusEl.focus({ preventScroll: true });
    }
  }
  syncRail();
  if (!quiet) flashSaved('Reverted');
}

function focusField(index, key) {
  const step = steps[index];
  if (!step) {
    if (document.activeElement) document.activeElement.blur();
    return;
  }
  const el = document.querySelector(`[data-fkey="${step.id}:${key}"]`);
  if (!el) return;
  setCurrent(index, { scroll: true });
  el.focus({ preventScroll: true });
  el.setSelectionRange(el.value.length, el.value.length);
  autosize(el);
}

function focusSnapshot() {
  const el = document.activeElement;
  if (!el || !el.dataset || !el.dataset.fkey) return null;
  return {
    fkey: el.dataset.fkey,
    value: el.value,
    start: el.selectionStart,
    end: el.selectionEnd,
  };
}

function restoreFocus(keep) {
  if (!keep) return;
  const el = document.querySelector(`[data-fkey="${keep.fkey}"]`);
  if (!el) return;
  if (keep.value !== el.value) el.value = keep.value; // in-flight text wins
  el.focus({ preventScroll: true });
  try { el.setSelectionRange(keep.start, keep.end); } catch { /* not selectable */ }
  autosize(el);
}

/* ------------------------------- autosize ------------------------------- */

function autosize(el) {
  if (!el || el.tagName !== 'TEXTAREA') return;
  if (el.classList.contains('step-note') && !el.value && document.activeElement !== el) {
    el.style.height = ''; // collapsed "add a note" affordance
    return;
  }
  el.style.height = 'auto';
  // box-sizing is border-box here, so the borders have to be added back on.
  const edges = el.offsetHeight - el.clientHeight;
  el.style.height = `${el.scrollHeight + edges}px`;
}

function sizeAll() {
  // Every field in the document grows to fit what is in it. The import pane
  // is the exception: what goes in it is a whole lab, and a textarea that
  // grew to two thousand lines would push its own buttons off the screen.
  document.querySelectorAll('textarea:not(.import-text)').forEach(autosize);
}

/* --------------------------------- undo --------------------------------- */

function pushUndo(entry) {
  undoStack.push(entry);
  if (undoStack.length > UNDO_MAX) undoStack.shift();
  syncUndoButton();
  return entry;
}

async function runUndo(entry) {
  await entry.run();
  syncUndoButton();
}

async function undo() {
  const entry = undoStack.pop();
  syncUndoButton();
  if (!entry) {
    flashSaved('Nothing to undo');
    return;
  }
  hideToast();
  await runUndo(entry);
}

function syncUndoButton() {
  const btn = $('undoBtn');
  if (!btn) return;
  btn.disabled = undoStack.length === 0;
  const top = undoStack[undoStack.length - 1];
  btn.title = top ? `Undo ${top.label.toLowerCase()} (Ctrl+Z)` : 'Nothing to undo';
}

/* ------------------------------- mutations ------------------------------ */

async function move(index, delta) {
  await reorder(index, index + delta);
}

async function reorder(from, to) {
  if (from < 0 || from >= steps.length) return;
  if (to < 0 || to >= steps.length || to === from) return;
  const before = steps.map((s) => s.id);
  const first = captureRects();
  const [moved] = steps.splice(from, 1);
  steps.splice(to, 0, moved);
  current = to;
  render();
  playFlip(first);
  const entry = pushUndo({ label: 'Reorder', run: () => restoreOrder(before) });
  toast(`Moved to position ${to + 1}`, entry);
  await commitOrder();
}

async function restoreOrder(ids) {
  const rank = new Map(ids.map((id, i) => [id, i]));
  const first = captureRects();
  steps.sort((a, b) => (rank.has(a.id) ? rank.get(a.id) : 1e9) - (rank.has(b.id) ? rank.get(b.id) : 1e9));
  render();
  playFlip(first);
  await commitOrder();
  flashSaved('Undone');
}

// Delete is instant and undoable: the image and thumbnail ride along in the
// undo entry, because deleteStep() drops them from storage.
async function remove(id) {
  if (indexOf(id) < 0) return;
  const snapshot = { ...steps[indexOf(id)] };
  const [image, thumb] = await Promise.all([getImage(id), getThumb(id)]);

  // The array can have shifted while those reads were in flight, so find the
  // step again rather than trusting an index from before the await.
  const at = indexOf(id);
  if (at < 0) return;

  const first = captureRects();
  steps.splice(at, 1);
  imgById.delete(id);
  thumbs.delete(id);
  current = Math.min(at, Math.max(0, steps.length - 1));
  render();
  playFlip(first);

  const entry = pushUndo({
    label: 'Delete',
    run: async () => {
      if (image) await setImage(id, image);
      if (thumb) await setThumb(id, thumb);
      const back = Math.min(at, steps.length);
      const rects = captureRects();
      steps.splice(back, 0, snapshot);
      imgById.set(id, image);
      thumbs.set(id, thumb);
      current = back;
      render();
      playFlip(rects);
      await commitOrder();
      flashSaved('Undone');
    },
  });

  toast(`${isStep(snapshot) ? `Step ${stampedLabel(snapshot) || at + 1}` : SECTION_KINDS[snapshot.kind] || 'Section'} deleted`, entry);
  await deleteStep(id);
  await commitOrder([id]);
}

// Numbers are baked into the screenshots, so any reshuffle re-stamps the
// callout on the images whose position actually changed.
async function commitOrder(removedIds) {
  return serialize(async () => {
    setSaved('Renumbering');
    // Only the steps whose stamped number is now wrong: moving a section
    // around, or adding one, changes nothing and costs no re-stamping, while
    // restarting the count at a heading rewrites every image after it.
    const changed = numbered().filter(
      ({ item, label }) => label != null && stampedLabel(item) !== label,
    );

    for (const { item, n, label } of changed) {
      if (item.badge) {
        const shot = await getImage(item.id);
        if (shot) {
          const out = await restamp(shot, item.badge, label);
          await setImage(item.id, out.image);
          await setThumb(item.id, out.thumb);
        }
      }
      item.n = n;
      item.label = label;
    }

    await persistSteps(steps, removedIds);
    await load();
    render();
    flashSaved();
    webext.runtime.sendMessage({ type: 'ms:refreshBadge' }).catch(() => {});
  });
}

function serialize(fn) {
  chain = chain.then(fn, fn);
  return chain;
}

/* ------------------------------ drag to sort ---------------------------- */

function onRailPointerDown(e) {
  if (e.button !== 0) return;
  const row = e.target.closest('.rail-row');
  if (!row || steps.length < 2) return;

  drag = {
    row,
    id: row.dataset.id,
    from: indexOf(row.dataset.id),
    startY: e.clientY,
    pointerId: e.pointerId,
    active: false,
    to: indexOf(row.dataset.id),
  };

  window.addEventListener('pointermove', onRailPointerMove);
  window.addEventListener('pointerup', onRailPointerUp);
  window.addEventListener('pointercancel', cancelDrag);
}

function onRailPointerMove(e) {
  if (!drag) return;
  const dy = e.clientY - drag.startY;

  if (!drag.active) {
    if (Math.abs(dy) < 5) return;
    drag.active = true;
    drag.rects = [...$('rail').children].map((el) => el.getBoundingClientRect());
    drag.row.classList.add('dragging');
    document.body.classList.add('sorting');
    try { drag.row.setPointerCapture(drag.pointerId); } catch { /* synthetic pointer */ }
  }

  drag.row.style.transform = `translateY(${dy}px)`;

  let slot = drag.rects.findIndex((r) => e.clientY < r.top + r.height / 2);
  if (slot === -1) slot = drag.rects.length;
  drag.to = slot > drag.from ? slot - 1 : slot;
  showDropLine(slot);
}

function showDropLine(slot) {
  const line = $('dropLine');
  const rail = $('rail');
  const rects = drag.rects;
  const railBox = rail.getBoundingClientRect();
  const hostBox = rail.parentElement.getBoundingClientRect();
  const raw = slot < rects.length ? rects[slot].top : rects[rects.length - 1].bottom;
  const y = Math.max(railBox.top, Math.min(raw, railBox.bottom));
  line.style.top = `${y - hostBox.top}px`;
  line.style.left = `${railBox.left - hostBox.left}px`;
  line.style.width = `${railBox.width - 4}px`;
  line.hidden = false;
}

function onRailPointerUp() {
  if (!drag) return;
  const { active, from, to } = drag;
  endDrag();
  if (!active) return;
  clickGuard = Date.now() + 350;
  if (to !== from) reorder(from, to);
}

function cancelDrag() {
  if (drag) endDrag();
}

function endDrag() {
  if (drag.row) {
    drag.row.classList.remove('dragging');
    drag.row.style.transform = '';
    try { drag.row.releasePointerCapture(drag.pointerId); } catch { /* already gone */ }
  }
  document.body.classList.remove('sorting');
  $('dropLine').hidden = true;
  drag = null;
  window.removeEventListener('pointermove', onRailPointerMove);
  window.removeEventListener('pointerup', onRailPointerUp);
  window.removeEventListener('pointercancel', cancelDrag);
}

/* ---------------------------- flip animation ---------------------------- */

function captureRects() {
  if (reduced()) return null;
  const map = new Map();
  document.querySelectorAll('[data-flip]').forEach((el) => {
    map.set(el.dataset.flip, el.getBoundingClientRect());
  });
  return map;
}

// The list re-renders from scratch, so rows are matched by step id and eased
// from where they used to be — a reorder reads as movement, not a jump cut.
function playFlip(first) {
  if (!first) return;
  document.querySelectorAll('[data-flip]').forEach((el) => {
    const was = first.get(el.dataset.flip);
    if (!was) return;
    const now = el.getBoundingClientRect();
    const dx = was.left - now.left;
    const dy = was.top - now.top;
    if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return;
    el.animate(
      [{ transform: `translate(${dx}px, ${dy}px)` }, { transform: 'none' }],
      { duration: 320, easing: 'cubic-bezier(.2,.85,.25,1)' },
    );
  });
}

/* ------------------------------- keyboard ------------------------------- */

function onKeydown(e) {
  if (!$('sheet').hidden) {
    if (e.key === 'Escape') closeSheet();
    return;
  }

  if (!$('importSheet').hidden) {
    // Not while it is downloading: Escape would leave the sheet's own state
    // behind the page it just closed.
    if (e.key === 'Escape' && !importing) closeImport();
    return;
  }

  if (!$('library').hidden && e.key === 'Escape') {
    e.preventDefault();
    closeLibrary();
    $('captureBtn').focus();
    return;
  }

  if (!$('addMenu').hidden && e.key === 'Escape') {
    e.preventDefault();
    closeAddMenu();
    return;
  }

  const mod = e.metaKey || e.ctrlKey;
  const el = document.activeElement;
  const inField = !!(el && el.matches('input, textarea'));

  if (mod && (e.key === 'z' || e.key === 'Z')) {
    if (inField && !e.shiftKey) return; // let the field's own history run first
    e.preventDefault();
    undo();
    return;
  }
  if (inField || mod || e.altKey) return;

  const onButton = !!(el && el.matches('button, summary, a'));

  switch (e.key) {
    case 'j':
    case 'ArrowDown':
      e.preventDefault();
      setCurrent(current + 1, { scroll: true });
      break;
    case 'k':
    case 'ArrowUp':
      e.preventDefault();
      setCurrent(current - 1, { scroll: true });
      break;
    case 'Enter':
      if (onButton) return;
      e.preventDefault();
      focusField(current, 'title');
      break;
    case 'n':
      if (onButton) return;
      e.preventDefault();
      focusField(current, 'note');
      break;
    case '?':
      if (onButton) return;
      e.preventDefault();
      $('keys').open = !$('keys').open;
      break;
    case 'Escape':
      hideToast();
      break;
    default:
  }
}

/* -------------------------------- exports ------------------------------- */

async function exportHtml() {
  setSaved('Building');
  const html = buildHtml({ guide, steps, images: imagesInOrder() });
  download(html, `${slugify(guide.title)}.html`, 'text/html');
  flashSaved('Exported');
}

async function exportMarkdown() {
  setSaved('Building');
  const blob = buildMarkdownZip({ guide, steps, images: imagesInOrder() });
  download(blob, `${slugify(guide.title)}.zip`);
  flashSaved('Exported');
}

/* -------------------------------- helpers ------------------------------- */

// Rewriting the title alone would leave the value sitting in the screenshot
// pixels and in the undo history — a redaction that only looks like one. This
// paints the field out of the image and drops the history, so it is permanent
// and the confirm says so.
function askRedact(step) {
  const blind = !step.spot || step.spot.left == null;
  ask(
    blind
      ? `Replace this value with dots? This step has no recorded field bounds, so the screenshot can't be painted over — check it yourself before exporting.`
      : `Paint "${step.text}" out of step ${stampedLabel(step) || indexOf(step.id) + 1}? The value is removed from the title and from the screenshot itself. This can't be undone.`,
    'Redact',
    () => redactStep(step.id),
  );
}

async function redactStep(id) {
  const step = steps.find((x) => x.id === id);
  if (!step) return;
  setSaved('Redacting');

  const current = await getImage(id);
  const masked = current ? await maskSpot(current, step.spot, step.badge, stampedLabel(step)) : null;
  if (masked) {
    await setImage(id, masked.image);
    await setThumb(id, masked.thumb);
  }

  if (step.text && step.title) step.title = swapValue(step.title, step.text, '••••••');
  step.text = '';
  await persistSteps(steps);

  undoStack = []; // an undo entry could put the value back
  syncUndoButton();
  await load();
  render();
  flashSaved(masked ? 'Redacted' : 'Text redacted only');
}

function deleteAllText() {
  const n = countSteps(steps);
  const sections = steps.length - n;
  const bits = [`${n} step${n === 1 ? '' : 's'}`];
  if (sections) bits.push(`${sections} section${sections === 1 ? '' : 's'}`);
  return `Delete this capture? All ${bits.join(' and ')} go with it, and it leaves the library.`;
}

function ask(text, okLabel, action) {
  confirmAction = action;
  $('sheetText').textContent = text;
  $('sheetOk').textContent = okLabel;
  $('sheet').hidden = false;
  $('sheetOk').focus();
}

function closeSheet() {
  confirmAction = null;
  $('sheet').hidden = true;
}

function toast(text, entry) {
  toastEntry = entry || null;
  $('toastText').textContent = text;
  const el = $('toast');
  el.hidden = false;
  requestAnimationFrame(() => el.classList.add('in'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, 6500);
}

function hideToast() {
  clearTimeout(toastTimer);
  toastEntry = null;
  const el = $('toast');
  el.classList.remove('in');
  el.hidden = true;
}

function setSaved(text) {
  clearTimeout(savedTimer);
  $('saved').textContent = text;
}

function flashSaved(text = 'Saved') {
  setSaved(text);
  savedTimer = setTimeout(() => ($('saved').textContent = ''), 1800);
}

function hostOf(url) {
  try {
    return new URL(url).host.replace(/^www\./, '');
  } catch {
    return '';
  }
}

function debounce(fn, ms) {
  let t = null;
  let pending = null;
  const run = (...args) => {
    pending = args;
    clearTimeout(t);
    t = setTimeout(() => {
      t = null;
      const a = pending;
      pending = null;
      fn(...a);
    }, ms);
  };
  run.now = () => {
    if (t === null) return;
    clearTimeout(t);
    t = null;
    const a = pending || [];
    pending = null;
    fn(...a);
  };
  run.cancel = () => {
    clearTimeout(t);
    t = null;
    pending = null;
  };
  return run;
}
